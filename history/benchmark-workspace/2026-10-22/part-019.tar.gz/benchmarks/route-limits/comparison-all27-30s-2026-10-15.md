# Los 27 ejemplos con límite por ruta: 30 segundos por motor

Se ejecutaron **54 pruebas**, una por combinación de instancia y motor. Cada ejecución usó la flota del catálogo y un presupuesto de 30 segundos que incluye preparación para el motor, arranque del worker/runtime, inicialización, búsqueda y validación de la aplicación. La importación previa del archivo y la construcción inicial de su matriz están fuera de ese reloj; sus tiempos se conservan por separado en el JSON. Las ejecuciones fueron secuenciales, con contextos, páginas y workers nuevos; sin pulido posterior.

El límite de duración incluye el regreso al depósito y el servicio de los clientes. La auditoría independiente volvió a calcular cobertura, capacidad y duración desde los archivos originales; comprobó también los límites conservadores enteros a escala 1000. No se aumentó la flota ni se relajaron los límites. Se verificaron 53 hashes de archivos contra el informe y los 27 archivos de instancia contra el catálogo.

## Cobertura y tiempos observados

| Motor | Soluciones completas válidas | Tiempo real, s (mín.–máx.) | Exceso máximo sobre 30 s, ms | Gap medio frente a BKS, solo casos propios factibles |
| --- | ---: | ---: | ---: | ---: |
| OR-Tools | 16/27 | 29,9998–30,0022 | 2,210 | +0,956% (16 casos) |
| PyVRP | 18/27 | 29,9998–30,0021 | 2,130 | +0,625% (18 casos) |

Los promedios de la última columna tienen su denominador indicado y **no comparan necesariamente el mismo conjunto de instancias**. Los fallos conservan coste y gap nulos, nunca cero. Un motor que termina antes puede haber devuelto un fallo; el presupuesto máximo no obliga a consumirlo entero.

## Comparación por instancia

Costes de distancia originales, sin redondear por arco; se muestran con dos decimales. Entre paréntesis, diferencia porcentual respecto al mejor coste conocido del catálogo (BKS), que no se asume óptimo. Los tiempos incluyen la inicialización. Servicio y límite usan las unidades de cada instancia. Un empate significa diferencia de coste ≤ 0,01 unidades; los valores completos se conservan en JSON. Los gaps próximos a cero pueden reflejar el redondeo del BKS publicado a dos decimales; no implican un nuevo récord.

| Instancia | Clientes | Flota máxima | Límite por ruta | Servicio por cliente | OR-Tools: coste (gap) / estado | Tiempo OR, s | PyVRP: coste (gap) / estado | Tiempo PV, s | Menor coste o cobertura |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| CMT6 | 50 | 6 | 200 | 10 | 556,68 (+0,225%) | 30,0021 | 555,43 (+0,000%) | 30,0003 | PyVRP |
| CMT7 | 75 | 11 | 160 | 10 | 920,56 (+1,196%) | 30,0008 | 909,68 (-0,001%) | 30,0007 | PyVRP |
| CMT8 | 100 | 9 | 230 | 10 | 871,07 (+0,592%) | 30,0007 | 865,94 (+0,001%) | 30,0009 | PyVRP |
| CMT9 | 150 | 14 | 200 | 10 | 1194,90 (+2,783%) | 30,0010 | 1164,12 (+0,135%) | 30,0004 | PyVRP |
| CMT10 | 199 | 18 | 200 | 10 | 1421,56 (+1,842%) | 30,0010 | 1401,20 (+0,383%) | 30,0007 | PyVRP |
| CMT13 | 120 | 11 | 720 | 50 | 1559,09 (+1,165%) | 30,0004 | 1542,86 (+0,112%) | 30,0002 | PyVRP |
| CMT14 | 100 | 11 | 1040 | 90 | 878,52 (+1,402%) | 30,0008 | 866,37 (-0,001%) | 30,0004 | PyVRP |
| Golden_1 | 240 | 9 | 650 | 0 | 5687,25 (+1,134%) | 30,0010 | 5662,34 (+0,691%) | 30,0011 | PyVRP |
| Golden_2 | 320 | 10 | 900 | 0 | 8459,90 (+0,658%) | 30,0012 | 8466,92 (+0,741%) | 30,0012 | OR-Tools |
| Golden_3 | 400 | 10 | 1200 | 0 | 11.037,42 (+0,360%) | 30,0005 | 11.044,61 (+0,426%) | 30,0008 | OR-Tools |
| Golden_4 | 480 | 10 | 1600 | 0 | 13.628,12 (+0,291%) | 30,0021 | 13.634,11 (+0,335%) | 30,0018 | OR-Tools |
| Golden_5 | 200 | 5 | 1800 | 0 | 6460,98 (+0,000%) | 30,0016 | 6460,98 (+0,000%) | 30,0016 | Empate |
| Golden_6 | 280 | 7 | 1500 | 0 | 8419,61 (+0,230%) | 30,0021 | 8535,35 (+1,607%) | 30,0011 | OR-Tools |
| Golden_7 | 360 | 8 | 1300 | 0 | Sin solución (no_solution) | 29,9999 | Sin solución (no_solution) | 30,0004 | Ninguna solución |
| Golden_8 | 440 | 10 | 1200 | 0 | Sin solución (no_solution) | 30,0004 | 11.743,80 (+0,933%) | 30,0005 | Solo PyVRP factible |
| Li_21 | 560 | 10 | 1800 | 0 | 16.217,62 (+0,030%) | 30,0009 | 16.397,34 (+1,138%) | 30,0021 | OR-Tools |
| Li_22 | 600 | 15 | 1000 | 0 | 14.652,28 (+1,057%) | 30,0013 | 14.753,02 (+1,752%) | 30,0012 | OR-Tools |
| Li_23 | 640 | 10 | 2200 | 0 | Sin solución (no_solution) | 29,9998 | 19.061,94 (+1,387%) | 30,0013 | Solo PyVRP factible |
| Li_24 | 720 | 10 | 2400 | 0 | Sin solución (no_solution) | 30,0003 | 21.733,66 (+1,609%) | 30,0011 | Solo PyVRP factible |
| Li_25 | 760 | 19 | 900 | 0 | 17.053,25 (+2,325%) | 30,0022 | Sin solución (no_solution) | 30,0013 | Solo OR-Tools factible |
| Li_26 | 800 | 10 | 2500 | 0 | Sin solución (no_solution) | 30,0015 | Sin solución (no_solution) | 30,0001 | Ninguna solución |
| Li_27 | 840 | 20 | 900 | 0 | Sin solución (no_solution) | 30,0005 | Sin solución (no_solution) | 30,0004 | Ninguna solución |
| Li_28 | 880 | 10 | 2800 | 0 | Sin solución (no_solution) | 30,0000 | Sin solución (no_solution) | 29,9998 | Ninguna solución |
| Li_29 | 960 | 10 | 3000 | 0 | Sin solución (no_solution) | 30,0002 | Sin solución (no_solution) | 30,0005 | Ninguna solución |
| Li_30 | 1040 | 10 | 3200 | 0 | Sin solución (no_solution) | 30,0005 | Sin solución (no_solution) | 29,9998 | Ninguna solución |
| Li_31 | 1120 | 10 | 3500 | 0 | Sin solución (no_solution) | 30,0000 | Sin solución (no_solution) | 30,0003 | Ninguna solución |
| Li_32 | 1200 | 11 | 3600 | 0 | Sin solución (no_solution) | 30,0008 | Sin solución (no_solution) | 30,0009 | Ninguna solución |

## Comparación sobre los mismos casos factibles

Ambos motores produjeron solución válida en **15/27** instancias. Sobre esos 15 pares, OR-Tools tuvo menor coste en **6**, PyVRP en **8**, y hubo **1** empate a tolerancia de 0,01 unidades. El gap medio frente a BKS en ese mismo conjunto fue +0,864% para OR-Tools y +0,488% para PyVRP.

- Solo OR-Tools entregó solución completa: Li_25.
- Solo PyVRP entregó solución completa: Golden_8, Li_23, Li_24.
- Ningún motor encontró solución completa en esta ejecución: Golden_7, Li_26, Li_27, Li_28, Li_29, Li_30, Li_31, Li_32.

La media de las diferencias porcentuales por instancia (100 × (coste OR-Tools / coste PyVRP − 1)) fue **+0,379%**; la mediana, **+0,225%**. Un valor negativo favorece el coste de OR-Tools. No se promedian ni suman costes absolutos de problemas de escalas diferentes. Esta es una ejecución por combinación, sin repetición ni inferencia estadística; describe esta máquina, versión y presupuesto, no una clasificación general de motores.

## Ejecuciones sin solución válida

- **Golden_7, OR-Tools**: no_solution, estado NO_SOLUTION, 29,9999 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Golden_7, PyVRP**: no_solution, estado NO_SOLUTION, 30,0004 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Golden_8, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0004 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_23, OR-Tools**: no_solution, estado NO_SOLUTION, 29,9998 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_24, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0003 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_25, PyVRP**: no_solution, estado NO_SOLUTION, 30,0013 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_26, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0015 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_26, PyVRP**: no_solution, estado NO_SOLUTION, 30,0001 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_27, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0005 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_27, PyVRP**: no_solution, estado NO_SOLUTION, 30,0004 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_28, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0000 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_28, PyVRP**: no_solution, estado NO_SOLUTION, 29,9998 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_29, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0002 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_29, PyVRP**: no_solution, estado NO_SOLUTION, 30,0005 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_30, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0005 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_30, PyVRP**: no_solution, estado NO_SOLUTION, 29,9998 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_31, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0000 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_31, PyVRP**: no_solution, estado NO_SOLUTION, 30,0003 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_32, OR-Tools**: no_solution, estado NO_SOLUTION, 30,0008 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_32, PyVRP**: no_solution, estado NO_SOLUTION, 30,0009 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.

No encontrar solución en esta ejecución no demuestra que la instancia sea inviable.

## Comprobación independiente de las soluciones entregadas

Cada fila representa una solución completa que pasó tanto las restricciones originales como las conservadoras enteras. La duración original incluye servicio y vuelta al depósito. La columna entera divide por 1000 la suma de viajes y servicios redondeados hacia arriba y la compara con el límite redondeado hacia abajo. Los costes enteros con redondeo al entero más cercano también se recomputaron y se guardan en la auditoría; el objetivo entero interno del motor no forma parte del resultado exportado y no se coteja por separado.

| Instancia | Motor | Vehículos usados / disponibles | Clientes cubiertos | Carga máxima / capacidad | Duración original máxima / límite | Duración conservadora máxima / límite |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| CMT6 | OR-Tools | 6/6 | 50/50 | 144/160 | 199,071014/200 | 199,077/200 |
| CMT6 | PyVRP | 6/6 | 50/50 | 155/160 | 199,115718/200 | 199,121/200 |
| CMT7 | OR-Tools | 11/11 | 75/75 | 139/140 | 159,705073/160 | 159,710/160 |
| CMT7 | PyVRP | 11/11 | 75/75 | 140/140 | 159,921167/160 | 159,925/160 |
| CMT8 | OR-Tools | 9/9 | 100/100 | 197/200 | 228,630286/230 | 228,637/230 |
| CMT8 | PyVRP | 9/9 | 100/100 | 199/200 | 227,928196/230 | 227,934/230 |
| CMT9 | OR-Tools | 14/14 | 150/150 | 191/200 | 199,617233/200 | 199,625/200 |
| CMT9 | PyVRP | 14/14 | 150/150 | 199/200 | 199,640977/200 | 199,647/200 |
| CMT10 | OR-Tools | 18/18 | 199/199 | 196/200 | 199,296181/200 | 199,302/200 |
| CMT10 | PyVRP | 18/18 | 199/199 | 200/200 | 198,972056/200 | 198,979/200 |
| CMT13 | OR-Tools | 11/11 | 120/120 | 165/200 | 717,674289/720 | 717,682/720 |
| CMT13 | PyVRP | 11/11 | 120/120 | 155/200 | 717,849555/720 | 717,858/720 |
| CMT14 | OR-Tools | 11/11 | 100/100 | 200/200 | 1028,040331/1040 | 1028,043/1040 |
| CMT14 | PyVRP | 11/11 | 100/100 | 200/200 | 1028,040331/1040 | 1028,043/1040 |
| Golden_1 | OR-Tools | 9/9 | 240/240 | 550/550 | 647,890175/650 | 647,905/650 |
| Golden_1 | PyVRP | 9/9 | 240/240 | 550/550 | 647,890562/650 | 647,906/650 |
| Golden_2 | OR-Tools | 10/10 | 320/320 | 700/700 | 888,358505/900 | 888,375/900 |
| Golden_2 | PyVRP | 10/10 | 320/320 | 680/700 | 897,773532/900 | 897,791/900 |
| Golden_3 | OR-Tools | 10/10 | 400/400 | 860/900 | 1117,745049/1200 | 1117,768/1200 |
| Golden_3 | PyVRP | 10/10 | 400/400 | 880/900 | 1169,528274/1200 | 1169,552/1200 |
| Golden_4 | OR-Tools | 10/10 | 480/480 | 970/1000 | 1367,160170/1600 | 1367,186/1600 |
| Golden_4 | PyVRP | 10/10 | 480/480 | 1000/1000 | 1429,556525/1600 | 1429,582/1600 |
| Golden_5 | OR-Tools | 5/5 | 200/200 | 810/900 | 1301,581991/1800 | 1301,606/1800 |
| Golden_5 | PyVRP | 5/5 | 200/200 | 840/900 | 1310,968114/1800 | 1310,992/1800 |
| Golden_6 | OR-Tools | 7/7 | 280/280 | 900/900 | 1304,540276/1500 | 1304,558/1500 |
| Golden_6 | PyVRP | 7/7 | 280/280 | 860/900 | 1449,782579/1500 | 1449,805/1500 |
| Golden_8 | PyVRP | 10/10 | 440/440 | 900/900 | 1199,549542/1200 | 1199,569/1200 |
| Li_21 | OR-Tools | 10/10 | 560/560 | 1180/1200 | 1646,018702/1800 | 1646,044/1800 |
| Li_21 | PyVRP | 10/10 | 560/560 | 1200/1200 | 1789,923029/1800 | 1789,951/1800 |
| Li_22 | OR-Tools | 15/15 | 600/600 | 820/900 | 998,800158/1000 | 998,824/1000 |
| Li_22 | PyVRP | 15/15 | 600/600 | 900/900 | 999,546771/1000 | 999,566/1000 |
| Li_23 | PyVRP | 10/10 | 640/640 | 1400/1400 | 2198,498488/2200 | 2198,528/2200 |
| Li_24 | PyVRP | 10/10 | 720/720 | 1500/1500 | 2381,408576/2400 | 2381,445/2400 |
| Li_25 | OR-Tools | 19/19 | 760/760 | 800/900 | 897,539906/900 | 897,563/900 |

## Evidencia reproducible

- [Resultados originales y rutas completas](./comparison-all27-30s-2026-10-15.json).
- [Auditoría independiente y estadísticas completas](./comparison-all27-30s-2026-10-15.audit.json).
- [Generador de esta auditoría](./summarize-all27.mjs).
- SHA-256 del JSON original: bd0e38a9974cd32646e32ce8122736298b92472fb1e073e317d30432e1818c11.
- Reproducir desde la raíz del repositorio: **node benchmarks/route-limits/summarize-all27.mjs**.

La tolerancia del test de tiempo (1000 ms) es una tolerancia de comprobación por planificación del navegador y manejo del resultado; los tiempos y excesos realmente observados se muestran arriba y permanecen sin recortar en los datos.
