# Los 27 ejemplos con límite por ruta: 60 segundos por motor

Se ejecutaron **54 pruebas**, una por combinación de instancia y motor. Cada ejecución usó la flota del catálogo y un presupuesto de 60 segundos que incluye preparación para el motor, arranque del worker/runtime, inicialización, búsqueda y validación de la aplicación. La importación previa del archivo y la construcción inicial de su matriz están fuera de ese reloj; sus tiempos se conservan por separado en el JSON. Las ejecuciones fueron secuenciales, con contextos, páginas y workers nuevos; sin pulido posterior.

El límite de duración incluye el regreso al depósito y el servicio de los clientes. La auditoría independiente volvió a calcular cobertura, capacidad y duración desde los archivos originales; comprobó también los límites conservadores enteros a escala 1000. No se aumentó la flota ni se relajaron los límites. Se verificaron 53 hashes de archivos contra el informe y los 27 archivos de instancia contra el catálogo.

## Cobertura y tiempos observados

| Motor | Soluciones completas válidas | Tiempo real, s (mín.–máx.) | Exceso máximo sobre 60 s, ms | Gap medio frente a BKS, solo casos propios factibles |
| --- | ---: | ---: | ---: | ---: |
| OR-Tools | 17/27 | 59,9999–60,0015 | 1,500 | +1,234% (17 casos) |
| PyVRP | 21/27 | 59,9997–60,0031 | 3,060 | +0,879% (21 casos) |

Los promedios de la última columna tienen su denominador indicado y **no comparan necesariamente el mismo conjunto de instancias**. Los fallos conservan coste y gap nulos, nunca cero. Un motor que termina antes puede haber devuelto un fallo; el presupuesto máximo no obliga a consumirlo entero.

## Comparación por instancia

Costes de distancia originales, sin redondear por arco; se muestran con dos decimales. Entre paréntesis, diferencia porcentual respecto al mejor coste conocido del catálogo (BKS), que no se asume óptimo. Los tiempos incluyen la inicialización. Servicio y límite usan las unidades de cada instancia. Un empate significa diferencia de coste ≤ 0,01 unidades; los valores completos se conservan en JSON. Los gaps próximos a cero pueden reflejar el redondeo del BKS publicado a dos decimales; no implican un nuevo récord.

| Instancia | Clientes | Flota máxima | Límite por ruta | Servicio por cliente | OR-Tools: coste (gap) / estado | Tiempo OR, s | PyVRP: coste (gap) / estado | Tiempo PV, s | Menor coste o cobertura |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| CMT6 | 50 | 6 | 200 | 10 | 556,68 (+0,225%) | 60,0015 | 555,43 (+0,000%) | 60,0022 | PyVRP |
| CMT7 | 75 | 11 | 160 | 10 | 917,80 (+0,893%) | 60,0009 | 909,68 (-0,001%) | 60,0011 | PyVRP |
| CMT8 | 100 | 9 | 230 | 10 | 866,56 (+0,072%) | 60,0015 | 865,94 (+0,001%) | 60,0008 | PyVRP |
| CMT9 | 150 | 14 | 200 | 10 | 1186,30 (+2,043%) | 60,0008 | 1164,12 (+0,135%) | 60,0005 | PyVRP |
| CMT10 | 199 | 18 | 200 | 10 | 1432,57 (+2,630%) | 60,0007 | 1401,20 (+0,383%) | 60,0015 | PyVRP |
| CMT13 | 120 | 11 | 720 | 50 | 1565,62 (+1,588%) | 60,0013 | 1542,86 (+0,112%) | 60,0003 | PyVRP |
| CMT14 | 100 | 11 | 1040 | 90 | 878,52 (+1,402%) | 60,0007 | 866,37 (-0,001%) | 60,0009 | PyVRP |
| Golden_1 | 240 | 9 | 650 | 0 | 5670,14 (+0,830%) | 60,0007 | 5645,17 (+0,386%) | 60,0005 | PyVRP |
| Golden_2 | 320 | 10 | 900 | 0 | 8459,90 (+0,658%) | 60,0009 | 8459,74 (+0,656%) | 60,0004 | PyVRP |
| Golden_3 | 400 | 10 | 1200 | 0 | 11.037,42 (+0,360%) | 60,0014 | 11.036,22 (+0,349%) | 60,0011 | PyVRP |
| Golden_4 | 480 | 10 | 1600 | 0 | 13.628,12 (+0,291%) | 60,0008 | 13.629,32 (+0,300%) | 60,0012 | OR-Tools |
| Golden_5 | 200 | 5 | 1800 | 0 | 6460,98 (+0,000%) | 60,0002 | 6460,98 (+0,000%) | 60,0020 | Empate |
| Golden_6 | 280 | 7 | 1500 | 0 | 8415,67 (+0,183%) | 60,0004 | 8535,35 (+1,607%) | 60,0031 | OR-Tools |
| Golden_7 | 360 | 8 | 1300 | 0 | Sin solución (no_solution) | 60,0002 | 10.332,00 (+2,270%) | 60,0010 | Solo PyVRP factible |
| Golden_8 | 440 | 10 | 1200 | 0 | Sin solución (no_solution) | 60,0000 | 11.713,86 (+0,675%) | 60,0012 | Solo PyVRP factible |
| Li_21 | 560 | 10 | 1800 | 0 | 16.217,62 (+0,030%) | 60,0008 | 16.393,67 (+1,115%) | 60,0012 | OR-Tools |
| Li_22 | 600 | 15 | 1000 | 0 | 14.652,28 (+1,057%) | 60,0008 | 14.644,66 (+1,004%) | 60,0006 | PyVRP |
| Li_23 | 640 | 10 | 2200 | 0 | 20.002,14 (+6,388%) | 60,0010 | 19.057,15 (+1,362%) | 60,0009 | PyVRP |
| Li_24 | 720 | 10 | 2400 | 0 | Sin solución (no_solution) | 60,0001 | 21.730,06 (+1,593%) | 60,0012 | Solo PyVRP factible |
| Li_25 | 760 | 19 | 900 | 0 | 17.053,25 (+2,325%) | 60,0008 | Sin solución (no_solution) | 60,0002 | Solo OR-Tools factible |
| Li_26 | 800 | 10 | 2500 | 0 | Sin solución (no_solution) | 60,0003 | Sin solución (no_solution) | 60,0000 | Ninguna solución |
| Li_27 | 840 | 20 | 900 | 0 | Sin solución (no_solution) | 60,0000 | 17.800,13 (+2,772%) | 60,0015 | Solo PyVRP factible |
| Li_28 | 880 | 10 | 2800 | 0 | Sin solución (no_solution) | 59,9999 | Sin solución (no_solution) | 59,9997 | Ninguna solución |
| Li_29 | 960 | 10 | 3000 | 0 | Sin solución (no_solution) | 60,0009 | Sin solución (no_solution) | 60,0001 | Ninguna solución |
| Li_30 | 1040 | 10 | 3200 | 0 | Sin solución (no_solution) | 59,9999 | Sin solución (no_solution) | 60,0005 | Ninguna solución |
| Li_31 | 1120 | 10 | 3500 | 0 | Sin solución (no_solution) | 60,0005 | Sin solución (no_solution) | 60,0009 | Ninguna solución |
| Li_32 | 1200 | 11 | 3600 | 0 | Sin solución (no_solution) | 60,0000 | 38.547,82 (+3,736%) | 60,0023 | Solo PyVRP factible |

## Comparación sobre los mismos casos factibles

Ambos motores produjeron solución válida en **16/27** instancias. Sobre esos 16 pares, OR-Tools tuvo menor coste en **3**, PyVRP en **12**, y hubo **1** empate a tolerancia de 0,01 unidades. El gap medio frente a BKS en ese mismo conjunto fue +1,166% para OR-Tools y +0,463% para PyVRP.

- Solo OR-Tools entregó solución completa: Li_25.
- Solo PyVRP entregó solución completa: Golden_7, Golden_8, Li_24, Li_27, Li_32.
- Ningún motor encontró solución completa en esta ejecución: Li_26, Li_28, Li_29, Li_30, Li_31.

La media de las diferencias porcentuales por instancia (100 × (coste OR-Tools / coste PyVRP − 1)) fue **+0,699%**; la mediana, **+0,148%**. Un valor negativo favorece el coste de OR-Tools. No se promedian ni suman costes absolutos de problemas de escalas diferentes. Esta es una ejecución por combinación, sin repetición ni inferencia estadística; describe esta máquina, versión y presupuesto, no una clasificación general de motores.

## Ejecuciones sin solución válida

- **Golden_7, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0002 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Golden_8, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0000 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_24, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0001 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_25, PyVRP**: no_solution, estado NO_SOLUTION, 60,0002 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_26, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0003 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_26, PyVRP**: no_solution, estado NO_SOLUTION, 60,0000 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_27, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0000 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_28, OR-Tools**: no_solution, estado NO_SOLUTION, 59,9999 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_28, PyVRP**: no_solution, estado NO_SOLUTION, 59,9997 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_29, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0009 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_29, PyVRP**: no_solution, estado NO_SOLUTION, 60,0001 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_30, OR-Tools**: no_solution, estado NO_SOLUTION, 59,9999 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_30, PyVRP**: no_solution, estado NO_SOLUTION, 60,0005 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_31, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0005 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_31, PyVRP**: no_solution, estado NO_SOLUTION, 60,0009 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.
- **Li_32, OR-Tools**: no_solution, estado NO_SOLUTION, 60,0000 s. Time budget exhausted before a feasible solution was available, including initialization. This does not prove infeasibility.

No encontrar solución en esta ejecución no demuestra que la instancia sea inviable.

## Comprobación independiente de las soluciones entregadas

Cada fila representa una solución completa que pasó tanto las restricciones originales como las conservadoras enteras. La duración original incluye servicio y vuelta al depósito. La columna entera divide por 1000 la suma de viajes y servicios redondeados hacia arriba y la compara con el límite redondeado hacia abajo. Los costes enteros con redondeo al entero más cercano también se recomputaron y se guardan en la auditoría; el objetivo entero interno del motor no forma parte del resultado exportado y no se coteja por separado.

| Instancia | Motor | Vehículos usados / disponibles | Clientes cubiertos | Carga máxima / capacidad | Duración original máxima / límite | Duración conservadora máxima / límite |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| CMT6 | OR-Tools | 6/6 | 50/50 | 144/160 | 199,071014/200 | 199,077/200 |
| CMT6 | PyVRP | 6/6 | 50/50 | 155/160 | 199,115718/200 | 199,121/200 |
| CMT7 | OR-Tools | 11/11 | 75/75 | 140/140 | 159,958673/160 | 159,965/160 |
| CMT7 | PyVRP | 11/11 | 75/75 | 140/140 | 159,921167/160 | 159,925/160 |
| CMT8 | OR-Tools | 9/9 | 100/100 | 199/200 | 227,928196/230 | 227,934/230 |
| CMT8 | PyVRP | 9/9 | 100/100 | 199/200 | 227,928196/230 | 227,934/230 |
| CMT9 | OR-Tools | 14/14 | 150/150 | 191/200 | 199,390547/200 | 199,397/200 |
| CMT9 | PyVRP | 14/14 | 150/150 | 199/200 | 199,640977/200 | 199,647/200 |
| CMT10 | OR-Tools | 18/18 | 199/199 | 200/200 | 199,350650/200 | 199,357/200 |
| CMT10 | PyVRP | 18/18 | 199/199 | 200/200 | 198,972056/200 | 198,979/200 |
| CMT13 | OR-Tools | 11/11 | 120/120 | 162/200 | 717,714062/720 | 717,722/720 |
| CMT13 | PyVRP | 11/11 | 120/120 | 155/200 | 717,849555/720 | 717,858/720 |
| CMT14 | OR-Tools | 11/11 | 100/100 | 200/200 | 1028,040331/1040 | 1028,043/1040 |
| CMT14 | PyVRP | 11/11 | 100/100 | 200/200 | 1028,040331/1040 | 1028,043/1040 |
| Golden_1 | OR-Tools | 9/9 | 240/240 | 550/550 | 647,890098/650 | 647,906/650 |
| Golden_1 | PyVRP | 9/9 | 240/240 | 550/550 | 647,890548/650 | 647,906/650 |
| Golden_2 | OR-Tools | 10/10 | 320/320 | 700/700 | 888,358505/900 | 888,375/900 |
| Golden_2 | PyVRP | 10/10 | 320/320 | 700/700 | 882,452868/900 | 882,469/900 |
| Golden_3 | OR-Tools | 10/10 | 400/400 | 860/900 | 1117,745049/1200 | 1117,768/1200 |
| Golden_3 | PyVRP | 10/10 | 400/400 | 900/900 | 1164,820462/1200 | 1164,844/1200 |
| Golden_4 | OR-Tools | 10/10 | 480/480 | 970/1000 | 1367,160170/1600 | 1367,186/1600 |
| Golden_4 | PyVRP | 10/10 | 480/480 | 1000/1000 | 1414,235829/1600 | 1414,261/1600 |
| Golden_5 | OR-Tools | 5/5 | 200/200 | 810/900 | 1301,581991/1800 | 1301,606/1800 |
| Golden_5 | PyVRP | 5/5 | 200/200 | 840/900 | 1310,968114/1800 | 1310,992/1800 |
| Golden_6 | OR-Tools | 7/7 | 280/280 | 860/900 | 1282,917910/1500 | 1282,933/1500 |
| Golden_6 | PyVRP | 7/7 | 280/280 | 860/900 | 1449,782579/1500 | 1449,805/1500 |
| Golden_7 | PyVRP | 8/8 | 360/360 | 900/900 | 1298,419863/1300 | 1298,446/1300 |
| Golden_8 | PyVRP | 10/10 | 440/440 | 900/900 | 1199,549605/1200 | 1199,569/1200 |
| Li_21 | OR-Tools | 10/10 | 560/560 | 1180/1200 | 1646,018702/1800 | 1646,044/1800 |
| Li_21 | PyVRP | 10/10 | 560/560 | 1200/1200 | 1785,215230/1800 | 1785,241/1800 |
| Li_22 | OR-Tools | 15/15 | 600/600 | 820/900 | 998,800158/1000 | 998,824/1000 |
| Li_22 | PyVRP | 15/15 | 600/600 | 890/900 | 998,799910/1000 | 998,822/1000 |
| Li_23 | OR-Tools | 10/10 | 640/640 | 1390/1400 | 2185,701972/2200 | 2185,736/2200 |
| Li_23 | PyVRP | 10/10 | 640/640 | 1400/1400 | 2120,446405/2200 | 2120,476/2200 |
| Li_24 | PyVRP | 10/10 | 720/720 | 1500/1500 | 2357,870770/2400 | 2357,907/2400 |
| Li_25 | OR-Tools | 19/19 | 760/760 | 800/900 | 897,539906/900 | 897,563/900 |
| Li_27 | PyVRP | 20/20 | 840/840 | 900/900 | 899,474297/900 | 899,493/900 |
| Li_32 | PyVRP | 11/11 | 1200/1200 | 2470/2500 | 3595,430217/3600 | 3595,486/3600 |

## Evidencia reproducible

- [Resultados originales y rutas completas](./comparison-all27-60s-2026-10-16.json).
- [Auditoría independiente y estadísticas completas](./comparison-all27-60s-2026-10-16.audit.json).
- [Generador de esta auditoría](./summarize-all27.mjs).
- SHA-256 del JSON original: 57f5c802ce726f47a33ca8fa287ab5f15cf0005e6ef1449fc5244ba685ee8f30.
- Reproducir desde la raíz del repositorio: **node benchmarks/route-limits/summarize-all27.mjs benchmarks/route-limits/comparison-all27-60s-2026-10-16.json**.

La tolerancia del test de tiempo (1000 ms) es una tolerancia de comprobación por planificación del navegador y manejo del resultado; los tiempos y excesos realmente observados se muestran arriba y permanecen sin recortar en los datos.
