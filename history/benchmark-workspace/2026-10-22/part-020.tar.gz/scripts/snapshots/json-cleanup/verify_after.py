from pathlib import Path
import hashlib, json, subprocess
root = Path('/home/sj_/projects/vibilia-routing')
data = root.parent / 'vibilia-routing-data'
audit = root / 'scripts/snapshots/json-cleanup'
plan = json.loads((audit / 'verified-delete-plan.json').read_text())
receipt = json.loads((audit / 'deletion-receipt.json').read_text(encoding='utf-8-sig'))
assert receipt['RemovedFiles'] == len(plan['files']) == 1306
assert all(not (root / item['path']).exists() for item in plan['files'])
remaining = list((root / 'public/benchmarks/solutions').rglob('*.json'))
assert not remaining
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
for item in plan['preserved']:
    assert sha(root / item['path']) == item['sha256'], item['path']
manifest = json.loads((data / 'manifest.json').read_text())
for entry in manifest['scenarios'].values():
    path = data / entry['path']
    assert path.stat().st_size == entry['bytes'] and sha(path) == entry['sha256']
assert subprocess.check_output(['git', '-C', str(data), 'status', '--porcelain'], text=True).strip() == ''
assert 'VITE_INSTANCE_RESULTS_BASE_URL=https://raw.githubusercontent.com/herreramonterrosa/vibilia-routing-data/main/' in (root / '.env.local').read_text()
result = {'removedJson': receipt['RemovedFiles'], 'freedBytes': receipt['RemovedBytes'], 'remainingSolutionCopies': len(remaining), 'unchangedNecessaryJson': len(plan['preserved']) - 1, 'legacyPreserved': True, 'dataScenariosVerified': len(manifest['scenarios']), 'dataRepositoryClean': True, 'appUsesRemoteData': True}
(audit / 'post-cleanup-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))