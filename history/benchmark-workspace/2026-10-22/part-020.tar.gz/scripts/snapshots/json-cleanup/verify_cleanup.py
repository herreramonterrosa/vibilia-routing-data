from pathlib import Path
import hashlib, json, subprocess
root = Path('/home/sj_/projects/vibilia-routing').resolve()
data = root.parent / 'vibilia-routing-data'
solutions = (root / 'public/benchmarks/solutions').resolve()
assert solutions == root / 'public/benchmarks/solutions'
commit = '16bfd32a2c474242dbc4769232d8c92fdcbeb423'
assert subprocess.check_output(['git', '-C', str(data), 'rev-parse', 'origin/main'], text=True).strip() == commit
assert subprocess.check_output(['git', '-C', str(data), 'status', '--porcelain'], text=True).strip() == ''
tracked = set(subprocess.check_output(['git', '-C', str(root), 'ls-files', '-z']).decode().split('\0'))
digest = lambda raw: hashlib.sha256(raw).hexdigest()
manifest_bytes = (data / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
assert len(manifest['scenarios']) == 832
assert (solutions / 'manifest.json').read_bytes() == manifest_bytes
current = {}
for example, entry in manifest['scenarios'].items():
    path = (data / entry['path']).resolve()
    assert path.is_relative_to(data.resolve())
    raw = path.read_bytes()
    assert len(raw) == entry['bytes'] and digest(raw) == entry['sha256']
    current[example] = (entry, json.loads(raw))
files = []
counts = {'manifest': 0, 'exact_scenario': 0, 'same_results_corrected_fleet_metadata': 0}
for path in sorted(solutions.rglob('*.json')):
    assert not path.is_symlink()
    assert path.resolve().is_relative_to(solutions)
    relative = path.relative_to(root).as_posix()
    assert relative not in tracked
    raw = path.read_bytes()
    item = {'path': relative, 'sha256': digest(raw), 'bytes': len(raw)}
    if path.name == 'manifest.json':
        assert raw == manifest_bytes
        item.update(kind='manifest', publishedPath='manifest.json')
    else:
        document = json.loads(raw)
        entry, published = current[document['exampleId']]
        item.update(publishedPath=entry['path'], publishedSha256=entry['sha256'])
        if item['sha256'] == entry['sha256']:
            assert document == published
            item['kind'] = 'exact_scenario'
        else:
            previous = document['instance']['vehicles']
            assert isinstance(previous, int) and published['instance']['vehicles'] is None
            document['instance']['vehicles'] = None
            assert document == published, relative
            item.update(kind='same_results_corrected_fleet_metadata', previousInferredVehicles=previous)
    counts[item['kind']] += 1
    files.append(item)
assert counts == {'manifest': 1, 'exact_scenario': 832, 'same_results_corrected_fleet_metadata': 473}, counts
assert sum(item['bytes'] for item in files) == 114271128
preserved_paths = [root / value for value in tracked if value.endswith('.json')]
preserved_paths += [root / 'public/benchmarks/instance-comparisons.json']
preserved = [{'path': path.relative_to(root).as_posix(), 'sha256': digest(path.read_bytes())} for path in preserved_paths if path.is_file()]
plan = {'dataCommit': commit, 'counts': counts, 'totalBytes': sum(item['bytes'] for item in files), 'files': files, 'preserved': preserved}
output = root / 'scripts/snapshots/json-cleanup/verified-delete-plan.json'
output.write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'counts': counts, 'bytes': plan['totalBytes'], 'preservedJsonSnapshots': len(preserved), 'plan': str(output)}))