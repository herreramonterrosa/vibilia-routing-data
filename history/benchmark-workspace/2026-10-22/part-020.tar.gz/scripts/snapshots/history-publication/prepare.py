from pathlib import Path
import json, hashlib, gzip, subprocess, collections, datetime, math
root = Path('/home/sj_/projects/vibilia-routing')
data = root.parent / 'vibilia-routing-data'
source = root / 'public/benchmarks/instance-comparisons.json'
audit = root / 'scripts/snapshots/history-publication'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
fields = ['exampleId', 'method', 'budgetSeconds', 'sourceSha256', 'family', 'dimension', 'profile', 'vehicles', 'capacity', 'originalServiceTotal', 'maxRouteDuration', 'outcome', 'valid', 'cost', 'elapsedMs', 'usedVehicles', 'gapPercent', 'reason']
def key(suite, record):
    return tuple(suite['budgetSeconds'] if field == 'budgetSeconds' else record.get(field) for field in fields)
def serializable_identity(values):
    return [int(value) if isinstance(value, float) and value.is_integer() else value for value in values]
raw = source.read_bytes()
assert sha(raw) == '94a4c37e6df09764ba4c89c5f67f6afd37ebd92a20c2f720913d8d6d8c3191f8'
legacy = json.loads(raw)
assert subprocess.check_output(['git', '-C', str(data), 'status', '--porcelain'], text=True).strip() == ''
commit = subprocess.check_output(['git', '-C', str(data), 'rev-parse', 'HEAD'], text=True).strip()
assert commit == subprocess.check_output(['git', '-C', str(data), 'rev-parse', 'origin/main'], text=True).strip()
manifest_bytes = (data / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
protected = {'manifest.json': sha(manifest_bytes)}
current = set(); current_count = 0
for entry in manifest['scenarios'].values():
    payload = (data / entry['path']).read_bytes()
    assert sha(payload) == entry['sha256'] and len(payload) == entry['bytes']
    protected[entry['path']] = sha(payload)
    scenario = json.loads(payload)
    for suite in scenario['suites']:
        for record in suite['records']:
            current.add(key(suite, record)); current_count += 1
historic = set(); measurements = []; represented_suites = set()
for si, suite in enumerate(legacy['suites']):
    for ri, record in enumerate(suite['records']):
        identity = key(suite, record)
        historic.add(identity)
        if identity not in current:
            identity_hash = sha(json.dumps(serializable_identity(identity), ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode())
            measurements.append({'id': identity_hash, 'suiteId': suite['id'], 'suiteIndex': si, 'recordIndex': ri, 'budgetSeconds': suite['budgetSeconds'], 'record': record})
            represented_suites.add(si)
assert len(current) == current_count == 4773
assert len(historic) == 5317
assert sum(len(s['records']) for s in legacy['suites']) == 15941
assert len(measurements) == len(historic - current) == 544
assert len({m['id'] for m in measurements}) == 544
assert current.issubset(historic)
assert len(represented_suites) == 13
outcomes = dict(sorted(collections.Counter(m['record']['outcome'] for m in measurements).items()))
assert outcomes == {'error':174,'feasible':51,'no_solution':16,'resource_limit':303}
assert sum('quarantine' in m['record'] for m in measurements) == 7
archive = gzip.compress(raw, compresslevel=9, mtime=0)
assert gzip.decompress(archive) == raw
history = data / 'history'
assert not history.exists(), 'Existing history needs append handling, not replacement'
history.mkdir()
archive_name = f'instance-comparisons.{sha(raw)}.json.gz'
(history / archive_name).write_bytes(archive)
index = {
    'schemaVersion': 1,
    'kind': 'historical-numeric-comparisons',
    'archivedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'canonicalBaseline': {'commit':commit,'manifestSha256':sha(manifest_bytes),'scenarioCount':len(manifest['scenarios']),'measurementCount':current_count},
    'archive': {'path':archive_name,'encoding':'gzip','sha256':sha(archive),'bytes':len(archive),'uncompressedSha256':sha(raw),'uncompressedBytes':len(raw),'originalName':'instance-comparisons.json'},
    'matching': {'fields':fields,'missingValues':'null','numbers':'Exact numeric equality, without rounding or tolerance.','reason':'Preserved verbatim, including null.','purpose':'Identify observations absent from the canonical baseline; this is not an equality test for all archival metadata.'},
    'summary': {'sourceSuites':len(legacy['suites']),'sourceRecordOccurrences':15941,'sourceUniqueMeasurements':len(historic),'additionalMeasurements':len(measurements),'additionalSuites':len(represented_suites),'additionalByOutcome':outcomes,'additionalByBudgetSeconds':dict(sorted(collections.Counter(m['budgetSeconds'] for m in measurements).items())),'quarantinedAdditionalMeasurements':7,'sourceCoverageEntries':len(legacy['coverage']),'sourceScenarioFailures':len(legacy['scenarioFailures'])},
    'suites': [{k:v for k,v in legacy['suites'][si].items() if k != 'records'} for si in sorted(represented_suites)],
    'measurements': measurements,
    'scenarioFailures': legacy['scenarioFailures'],
}
index_bytes = (json.dumps(index, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()
(history / 'index.json').write_bytes(index_bytes)
(audit / 'protected-current-files.json').write_text(json.dumps(protected, indent=2) + '\n')
(audit / 'prepared.json').write_text(json.dumps({'archiveSha256':sha(archive),'sourceSha256':sha(raw),'indexSha256':sha(index_bytes),'summary':index['summary']},indent=2)+'\n')
print(json.dumps({'archiveBytes':len(archive),'indexBytes':len(index_bytes),'summary':index['summary'],'protectedFiles':len(protected)}))