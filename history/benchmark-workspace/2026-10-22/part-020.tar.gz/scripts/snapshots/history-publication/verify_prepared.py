from pathlib import Path
import json, gzip, hashlib, collections
root=Path('/home/sj_/projects/vibilia-routing'); data=root.parent/'vibilia-routing-data'; audit=root/'scripts/snapshots/history-publication'
index=json.loads((data/'history/index.json').read_text())
archive=(data/'history'/index['archive']['path']).read_bytes()
source=(root/'public/benchmarks/instance-comparisons.json').read_bytes()
assert gzip.decompress(archive)==source
assert hashlib.sha256(archive).hexdigest()==index['archive']['sha256']
old=json.loads(source)
assert len(index['measurements'])==544
assert len({m['id'] for m in index['measurements']})==544
headers={s['id']:s for s in index['suites']}
for m in index['measurements']:
    s=old['suites'][m['suiteIndex']]
    assert s['id']==m['suiteId'] and m['budgetSeconds']==s['budgetSeconds']
    assert s['records'][m['recordIndex']]==m['record']
    assert headers[s['id']]=={k:v for k,v in s.items() if k!='records'}
assert index['scenarioFailures']==old['scenarioFailures']
protected=json.loads((audit/'protected-current-files.json').read_text())
for p,h in protected.items(): assert hashlib.sha256((data/p).read_bytes()).hexdigest()==h,p
assert not any('routes' in m['record'] for m in index['measurements'])
print(json.dumps({'archiveRestoresExactSource':True,'additionalMeasurements':len(index['measurements']),'suiteContexts':len(headers),'quarantines':sum('quarantine' in m['record'] for m in index['measurements']),'scenarioFailures':len(index['scenarioFailures']),'currentFilesUnchanged':len(protected)}))