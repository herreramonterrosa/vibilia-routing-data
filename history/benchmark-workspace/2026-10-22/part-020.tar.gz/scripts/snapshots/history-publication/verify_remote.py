from pathlib import Path
from urllib.request import urlopen, Request
import json, hashlib, gzip, subprocess, datetime
root=Path('/home/sj_/projects/vibilia-routing'); data=root.parent/'vibilia-routing-data'; audit=root/'scripts/snapshots/history-publication'
commit='1f1780a9918bc696c053452705f5cf7d5156a0fd'
base=f'https://raw.githubusercontent.com/herreramonterrosa/vibilia-routing-data/{commit}/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
def download(path):
    with urlopen(Request(base+path,headers={'User-Agent':'vibilia-history-verification','Cache-Control':'no-cache'}),timeout=60) as response:
        assert response.status==200
        return response.read()
index_bytes=download('history/index.json')
assert index_bytes==(data/'history/index.json').read_bytes()
index=json.loads(index_bytes)
archive_bytes=download('history/'+index['archive']['path'])
assert len(archive_bytes)==index['archive']['bytes'] and sha(archive_bytes)==index['archive']['sha256']
recovered=gzip.decompress(archive_bytes)
source=root/'public/benchmarks/instance-comparisons.json'
assert recovered==source.read_bytes()
assert sha(recovered)==index['archive']['uncompressedSha256']
assert len(recovered)==index['archive']['uncompressedBytes']
legacy=json.loads(recovered)
assert len(index['measurements'])==544
for m in index['measurements']:
    suite=legacy['suites'][m['suiteIndex']]
    assert suite['id']==m['suiteId'] and suite['records'][m['recordIndex']]==m['record']
assert index['scenarioFailures']==legacy['scenarioFailures']
protected=json.loads((audit/'protected-current-files.json').read_text())
for p,h in protected.items(): assert sha((data/p).read_bytes())==h,p
remote_manifest=download('manifest.json')
assert sha(remote_manifest)==protected['manifest.json']
manifest=json.loads(remote_manifest)
xl=manifest['scenarios']['cvrplib-xl-xl-n7037-k38']
xl_bytes=download(xl['path'])
assert sha(xl_bytes)==xl['sha256'] and len(xl_bytes)==xl['bytes']
paths=subprocess.check_output(['git','-C',str(data),'diff','--name-only',index['canonicalBaseline']['commit'],commit],text=True).splitlines()
assert set(paths)=={'README.md','history/README.md','history/index.json','history/'+index['archive']['path']},paths
result={'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'publishedCommit':commit,'indexUrl':base+'history/index.json','archiveUrl':base+'history/'+index['archive']['path'],'publishedMeasurements':len(index['measurements']),'archiveSha256':sha(archive_bytes),'restoredSourceSha256':sha(recovered),'restoredSourceBytes':len(recovered),'restoresOriginalByteForByte':True,'currentFilesUnchanged':len(protected),'publicCurrentManifestUnchanged':True,'publicXlScenarioVerified':True}
(audit/'remote-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))