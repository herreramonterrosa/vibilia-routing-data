from pathlib import Path
import json, collections, hashlib, gzip
root = Path('/home/sj_/projects/vibilia-routing')
p = root / 'public/benchmarks/instance-comparisons.json'
raw = p.read_bytes(); data = json.loads(raw)
print(json.dumps({'keys':list(data), 'bytes':len(raw), 'sha256':hashlib.sha256(raw).hexdigest(),'gzipBytes':len(gzip.compress(raw,mtime=0)), 'suiteCount':len(data['suites'])}))
for suite in data['suites']:
    print(json.dumps({'id':suite['id'],'budget':suite['budgetSeconds'],'keys':list(suite),'records':len(suite['records']),'firstRecordKeys':list(suite['records'][0]),'firstRecord':suite['records'][0]},ensure_ascii=False)[:5000])
for key in data:
    if key != 'suites': print(json.dumps({key: data[key]})[:4000])