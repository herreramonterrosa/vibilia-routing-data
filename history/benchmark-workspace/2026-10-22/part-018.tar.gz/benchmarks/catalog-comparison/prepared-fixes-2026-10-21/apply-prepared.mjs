import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

// This helper never stops a process, launches a solver, or changes saved runs.
const bundle = dirname(fileURLToPath(import.meta.url));
const root = resolve(bundle, "../../..");
const catalog = resolve(root, "benchmarks/catalog-comparison");
const args = process.argv.slice(2);
if (args.length > 1 || (args.length && !["--check", "--apply"].includes(args[0]))) {
    throw new Error("Use --check (default) or --apply after the current catalog invocation finishes.");
}
const apply = args[0] === "--apply";
const manifest = JSON.parse(readFileSync(resolve(bundle, "manifest.json"), "utf8"));
if (!Array.isArray(manifest.files) || !manifest.files.length) throw new Error("The prepared manifest has no source files.");
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
const alive = (pid) => {
    if (!Number.isSafeInteger(pid) || pid <= 0) return false;
    try { process.kill(pid, 0); return true; } catch (error) {
        return error.code !== "ESRCH";
    }
};
function inside(base, relative) {
    const path = resolve(base, relative);
    if (!path.startsWith(base + sep)) throw new Error(`Unsafe bundle path: ${relative}`);
    return path;
}
function preflight() {
    const blockers = [];
    const executionPath = resolve(catalog, "execution.json");
    const execution = existsSync(executionPath) ? JSON.parse(readFileSync(executionPath, "utf8")) : null;
    if (execution && (alive(execution.pid) || alive(execution.childPid))) {
        blockers.push("The catalog supervisor or its worker is still alive; leave it running.");
    }
    const latestPath = resolve(catalog, "latest.json");
    if (!existsSync(latestPath)) blockers.push("No catalog checkpoint is available.");
    else {
        const latest = JSON.parse(readFileSync(latestPath, "utf8"));
        const report = JSON.parse(readFileSync(inside(root, latest.reportPath), "utf8"));
        if (report.scheduling?.pendingRuns !== 0) blockers.push("The catalog still has pending measurements.");
        if (report.scheduling?.activeRun) blockers.push("The catalog checkpoint still has an active measurement.");
    }
    const entries = manifest.files.map((entry) => {
        // Corrections are source files only, never catalog reports or raw runs.
        if (typeof entry.path !== "string" || entry.path.includes("\\") || entry.path.split("/").some((part) => !part || part === "." || part === "..")) {
            throw new Error(`Noncanonical source path: ${entry.path}`);
        }
        if (!/^(src|e2e|scripts|compilations)\//.test(entry.path) && entry.path !== "benchmarks/catalog-comparison/vroom-abort-diagnostic.mjs") {
            throw new Error(`Unexpected source path: ${entry.path}`);
        }
        const target = inside(root, entry.path);
        const source = inside(resolve(bundle, "files"), entry.path);
        const bytes = readFileSync(source);
        if (hash(bytes) !== entry.sha256) throw new Error(`Prepared file was modified: ${entry.path}`);
        const original = existsSync(target) ? readFileSync(target) : null;
        if ((original ? hash(original) : null) !== entry.originalSha256) {
            blockers.push(`The source has changed since preparation: ${entry.path}`);
        }
        return { ...entry, target, bytes, original };
    });
    return { blockers, entries };
}
const checked = preflight();
if (!apply || checked.blockers.length) {
    console.log(JSON.stringify({ applied: false, ready: checked.blockers.length === 0, files: checked.entries.length, blockers: checked.blockers }, null, 2));
    if (apply) process.exitCode = 2;
} else {
    // The supervisor uses this same exclusive lock. Holding it also prevents a
    // fresh invocation from starting between our checks and source replacement.
    const lockPath = resolve(catalog, "execution.lock");
    writeFileSync(lockPath, String(process.pid), { flag: "wx" });
    const written = [];
    try {
        const rechecked = preflight();
        if (rechecked.blockers.length) throw new Error(rechecked.blockers.join("\n"));
        for (const entry of rechecked.entries) {
            const backup = inside(resolve(bundle, "originals"), entry.path);
            if (entry.original) {
                mkdirSync(dirname(backup), { recursive: true });
                if (existsSync(backup)) {
                    if (hash(readFileSync(backup)) !== entry.originalSha256) throw new Error(`Unexpected backup contents: ${entry.path}`);
                } else writeFileSync(backup, entry.original, { flag: "wx" });
            }
            mkdirSync(dirname(entry.target), { recursive: true });
            const temporary = `${entry.target}.second-pass-${process.pid}.tmp`;
            try {
                writeFileSync(temporary, entry.bytes, { flag: "wx" });
                renameSync(temporary, entry.target);
            } finally {
                if (existsSync(temporary)) unlinkSync(temporary);
            }
            written.push(entry);
        }
        writeFileSync(resolve(bundle, "application.json"), JSON.stringify({ appliedAt: new Date().toISOString(), files: manifest.files }, null, 2) + "\n", { flag: "wx" });
        console.log(JSON.stringify({ applied: true, files: written.length, next: "Use the canonical filtered catalog run described in README.md; do not delete existing observations." }, null, 2));
    } catch (error) {
        for (const entry of written.reverse()) {
            if (entry.original) writeFileSync(entry.target, entry.original);
            else unlinkSync(entry.target);
        }
        throw error;
    } finally {
        if (existsSync(lockPath) && readFileSync(lockPath, "utf8") === String(process.pid)) unlinkSync(lockPath);
    }
}
