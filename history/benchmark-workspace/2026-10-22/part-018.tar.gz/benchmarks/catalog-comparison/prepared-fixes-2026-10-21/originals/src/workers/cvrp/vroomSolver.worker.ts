/// <reference lib="webworker" />
import { jsonMatrix } from "../shared/jsonMatrix";
import type { DenseMatrix } from "@/lib/denseMatrix";
/**
 * Web Worker that solves CVRP through the VROOM wasm module.
 *
 * The same `solve(input_json, exploration_level)` embind entry used for TSP also
 * handles multi-vehicle problems with capacities/demands — VROOM was designed
 * around the VRP standard. See compilations/vroom/instructions.md.
 */
import { reportFatalWasmAbort, runSolverWorker, type SolverRunContext } from "../shared/harness";
import { returningSearchSeconds } from "../shared/solveBudget";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import { vroomTimeoutMs } from "@/planner/engines/vroomAdapter";
import type { CvrpRoute, CvrpSolution, CvrpSolveRequest } from "@/types/solver";

// Exploration threads per solve — half the pthread pool baked into vroom.js.
const VROOM_THREADS = 4;

interface VroomModule {
    solveWithTimeout: (inputJson: string, explorationLevel: number, nbThreads: number, timeoutMs: number) => string;
    version: () => string;
}

type VroomFactory = (opts?: Record<string, unknown>) => Promise<VroomModule>;

let modulePromise: Promise<VroomModule & AbortAwareModule> | null = null;

async function loadModule(): Promise<VroomModule & AbortAwareModule> {
    if (modulePromise) return modulePromise;
    modulePromise = (async () => {
        const url = new URL("/wasm/vroom.js", self.location.origin).toString();
        const mod = (await import(/* @vite-ignore */ url)) as { default: VroomFactory };
        return loadAbortAwareModule(mod.default, "VROOM", reportFatalWasmAbort);
    })();
    return modulePromise;
}

interface VroomStep {
    type: "start" | "job" | "end" | string;
    location_index?: number;
}

interface VroomVehicleRoute {
    vehicle: number;
    steps: VroomStep[];
    cost?: number;
    distance?: number;
}

interface VroomOutput {
    code?: number;
    error?: string;
    summary?: { cost?: number; distance?: number };
    routes?: VroomVehicleRoute[];
    unassigned?: Array<{ id: number; location_index?: number }>;
}

function buildInput(payload: CvrpSolveRequest): string {
    const { distanceMatrix, depot, demands, numVehicles, vehicleCapacity } = payload;
    const matrix = jsonMatrix(distanceMatrix);
    const vehicles = Array.from({ length: numVehicles }, (_, i) => ({
        id: i,
        start_index: depot,
        end_index: depot,
        // VROOM uses arrays so multi-dimensional capacities are supported. We
        // only have a single dimension; the worker reuses the configured cap.
        capacity: [vehicleCapacity],
    }));
    const jobs = [];
    for (let i = 0; i < matrix.length; i++) {
        if (i === depot) continue;
        jobs.push({
            id: i,
            location_index: i,
            delivery: [Math.max(0, Math.round(demands[i] ?? 0))],
        });
    }
    return JSON.stringify({
        vehicles,
        jobs,
        matrices: { car: { durations: matrix } },
    });
}

function sequenceFromRoute(route: VroomVehicleRoute): number[] {
    const seq: number[] = [];
    for (const step of route.steps) {
        if (step.location_index != null) seq.push(step.location_index);
    }
    return seq;
}

function routeDistance(seq: number[], matrix: DenseMatrix): number {
    let cost = 0;
    for (let i = 0; i + 1 < seq.length; i++) cost += matrix[seq[i]!]![seq[i + 1]!]!;
    return cost;
}

function routeLoad(seq: number[], demands: number[]): number {
    let load = 0;
    for (const idx of seq) load += demands[idx] ?? 0;
    return load;
}

async function solve(payload: CvrpSolveRequest, context: SolverRunContext<CvrpSolution>): Promise<CvrpSolution> {
    const mod = await loadModule();
    const requestStart = performance.now();
    // Exploration level mirrors the CLI `-x` flag (0 fast .. 5 default/best).
    const level = payload.vroomExplorationLevel ?? 5;
    const outJson = runWithAbortReason(mod, "VROOM", () =>
        mod.solveWithTimeout(
            buildInput(payload),
            level,
            VROOM_THREADS,
            vroomTimeoutMs(returningSearchSeconds(context.deadlineAtMs, payload.timeLimitSeconds)),
        ),
    );
    const clientMs = Math.round(performance.now() - requestStart);
    const result = JSON.parse(outJson) as VroomOutput;

    if (result.code != null && result.code !== 0) {
        return empty("ERROR", clientMs, result.error ?? `VROOM error code ${result.code}`);
    }
    const rawRoutes = (result.routes ?? []).filter((r) => r.steps.length > 0);
    const routes: CvrpRoute[] = rawRoutes.map((r) => {
        const sequence = sequenceFromRoute(r);
        return {
            vehicle: r.vehicle,
            sequence,
            distance: routeDistance(sequence, payload.distanceMatrix),
            load: routeLoad(sequence, payload.demands),
        };
    });
    const totalCost = routes.reduce((s, r) => s + r.distance, 0);
    // Job IDs are matrix indices in this adapter, even if a native result omits location_index.
    const unassignedBySolver = result.unassigned?.map((job) => job.location_index ?? job.id);
    const dropped = unassignedBySolver ?? [];

    return {
        status: "FEASIBLE",
        totalCost,
        wallTimeMs: clientMs,
        clientMs,
        routes,
        dropped,
        ...(unassignedBySolver === undefined ? {} : { unassignedBySolver }),
    };
}

function empty(status: CvrpSolution["status"], clientMs: number, error?: string): CvrpSolution {
    return { status, error, totalCost: 0, wallTimeMs: clientMs, clientMs, routes: [], dropped: [] };
}

runSolverWorker({ init: loadModule, solve });
