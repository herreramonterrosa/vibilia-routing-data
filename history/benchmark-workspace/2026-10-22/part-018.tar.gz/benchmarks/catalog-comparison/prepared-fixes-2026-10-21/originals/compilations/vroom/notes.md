# VROOM WASM build notes

The pinned source lives in `compilations/.deps/vroom-upstream.git`; each build
uses a temporary worktree. Compiled objects live under
`compilations/.build/vroom/<build-key>/`. The key includes the source tree,
submodule heads, local wrapper and patch, compiler version, and flags.

The current build keeps VROOM's pthread search. The Emscripten module prestarts
eight pool workers (`PTHREAD_POOL_SIZE=8`), while application calls request four
threads per solve by default (internal Planner benchmarks can request 1–8).
Upstream launches one pthread for every search rank before its semaphore can
throttle work: exploration level 5 produces 32 ranks. Patch
`0003-bounded-search-threads.patch` uses a bounded worker loop to run all ranks
with at most the requested number of threads, so the eight-worker pool covers
the maximum accepted request. Pool workers must exist before VROOM enters its
blocking search; otherwise `pthread_create` may deadlock while the caller waits
for a new worker. The module uses shared memory, so deployments need cross-origin
isolation (COOP/COEP). The repository's Vite configuration supplies those
headers for local development.

`-fwasm-exceptions` enables caught errors in the C++ wrapper.
`-fexperimental-library` makes the required libc++ threading types available.
`0002-wasm-libcxx-dedupe.patch` removes duplicate explicit template
instantiations caused by libc++ iterator aliases. The old sequential patch is
kept only for reference. Sources for the CLI, remote routing, and GLPK checks
are excluded from the browser build.

VROOM is a metaheuristic and the application reports `FEASIBLE`, not an
optimality proof. Its native timeout can stop search with the best solution
found so far. The wrapper rejects exploration values outside 0–5 and negative
timeouts as JSON errors, then remains usable for later calls.

## P-n55-k15 incomplete search (2026-10-18)

The unchanged shipped module reproduces the catalog's partial result with 15
vehicles of capacity 70, exploration level 5 and four search threads. Total
demand is 1042 against 1050 available capacity. It explicitly returns customer
index 11 (source ID 12, demand 37) in `unassigned`; all 15 returned routes obey
capacity, but their free space is fragmented. This is a heuristic result without
a complete incumbent, not an infeasibility proof or an adapter losing a visit.

A native diagnostic with a 10-second total budget, including module loading,
finished in about 1.52 seconds with that partial result. Sorting jobs by demand
without changing IDs, priorities or costs also left this customer unassigned;
the application keeps its original input order. No capacities, vehicle counts,
priorities, objectives or binaries were changed to make this instance pass.
The partial travel cost must not be compared with the full benchmark optimum.

`PARTIAL_NATIVE_REGRESSION=1` enables
`src/workers/shared/__tests__/partialNativeRegression.spec.ts`. It runs each
engine in an externally bounded subprocess, checks native unassigned IDs
against independent route coverage, and rejects any extra constraint failure.
The source hash is
`9ffe8a99263ee459960db909fb61651a66f86815a1781f17140812119596bad4`.
