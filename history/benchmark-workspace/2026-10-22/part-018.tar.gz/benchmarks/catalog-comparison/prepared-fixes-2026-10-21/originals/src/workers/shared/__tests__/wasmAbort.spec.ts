import { describe, expect, it } from "vitest";
import { loadAbortAwareModule, runWithAbortReason, WasmAbortPending } from "../wasmAbort";

describe("Emscripten abort reasons", () => {
    it("keeps a concrete abort reason through an unreachable trap", async () => {
        let onAbort: (reason: unknown) => void = () => {};
        const mod = await loadAbortAwareModule(async (options) => {
            onAbort = options!["onAbort"] as typeof onAbort;
            return {};
        }, "VROOM");
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                onAbort("OOM");
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("VROOM aborted: OOM");
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("unreachable");
    });

    it("keeps an abort reason when module startup fails", async () => {
        await expect(
            loadAbortAwareModule(async (options) => {
                (options!["onAbort"] as (reason: unknown) => void)("Cannot enlarge memory arrays (OOM)");
                throw new WebAssembly.RuntimeError("unreachable");
            }, "OR-Tools"),
        ).rejects.toThrow("OR-Tools aborted during initialization: Cannot enlarge memory arrays (OOM)");
    });

    it("waits for a child-thread abort instead of reporting Emscripten's unwind sentinel", async () => {
        let onAbort: (reason: unknown) => void = () => {};
        const reported: Array<[string, string]> = [];
        const mod = await loadAbortAwareModule(
            async (options) => {
                onAbort = options!["onAbort"] as typeof onAbort;
                return {};
            },
            "VROOM",
            (engine, reason) => reported.push([engine, reason]),
        );
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                throw "unwind";
            }),
        ).toThrow(WasmAbortPending);
        expect(reported).toEqual([]);
        onAbort("OOM");
        expect(reported).toEqual([["VROOM", "OOM"]]);
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                throw new Error("unreachable");
            }),
        ).toThrow("unreachable");
    });
});
