/// <reference lib="webworker" />
import { jsonMatrix } from "../shared/jsonMatrix";
import type { DenseMatrix } from "@/lib/denseMatrix";
/**
 * Web Worker that solves TSP with VROOM (vehicle routing engine) running in
 * WebAssembly. The wrapper exposes a single embind function `solve(json, level)`
 * that takes VROOM's standard JSON format and returns a JSON result.
 *
 * The wrapper contract is documented in compilations/vroom/instructions.md.
 *
 * VROOM is a metaheuristic, so we report `FEASIBLE`, not `OPTIMAL`.
 */
import { reportFatalWasmAbort, runSolverWorker, type SolverRunContext } from "../shared/harness";
import { returningSearchSeconds } from "../shared/solveBudget";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import { vroomTimeoutMs } from "@/planner/engines/vroomAdapter";
import type { TspSolution, TspSolveRequest } from "@/types/solver";

// Exploration threads per solve — half the pthread pool baked into vroom.js.
const VROOM_THREADS = 4;

interface VroomModule {
    solveWithTimeout: (inputJson: string, explorationLevel: number, nbThreads: number, timeoutMs: number) => string;
    version: () => string;
}

type VroomFactory = (opts?: Record<string, unknown>) => Promise<VroomModule>;

let modulePromise: Promise<VroomModule & AbortAwareModule> | null = null;

async function loadModule(): Promise<VroomModule & AbortAwareModule> {
    if (modulePromise) return modulePromise;
    modulePromise = (async () => {
        const url = new URL("/wasm/vroom.js", self.location.origin).toString();
        const mod = (await import(/* @vite-ignore */ url)) as { default: VroomFactory };
        return loadAbortAwareModule(mod.default, "VROOM", reportFatalWasmAbort);
    })();
    return modulePromise;
}

interface VroomStep {
    type: "start" | "job" | "end" | string;
    location_index?: number;
    job?: number;
}

interface VroomRoute {
    vehicle: number;
    steps: VroomStep[];
    cost?: number;
    distance?: number;
    duration?: number;
}

interface VroomResult {
    code?: number;
    error?: string;
    summary?: { cost?: number; distance?: number; duration?: number };
    routes?: VroomRoute[];
}

// Builds VROOM's standard input. One vehicle starts and ends at the depot, every
// other matrix index becomes a `job` that must be visited exactly once. The
// "matrices.car.durations" payload supplies the cost matrix in lieu of a routing
// server (we are running USE_ROUTING=false).
function buildInput(matrix: DenseMatrix, depot: number): string {
    const n = matrix.length;
    const rounded = jsonMatrix(matrix);
    const jobs: Array<{ id: number; location_index: number }> = [];
    for (let i = 0; i < n; i++) {
        if (i !== depot) jobs.push({ id: i, location_index: i });
    }
    return JSON.stringify({
        vehicles: [{ id: 0, start_index: depot, end_index: depot }],
        jobs,
        matrices: { car: { durations: rounded } },
    });
}

// Translates a VROOM route into the closed `[depot, ..., depot]` sequence in
// matrix-index space the UI expects.
function extractSequence(route: VroomRoute): number[] {
    const seq: number[] = [];
    for (const step of route.steps) {
        if (step.location_index != null) seq.push(step.location_index);
    }
    return seq;
}

function recomputeCost(sequence: number[], matrix: DenseMatrix): number {
    let cost = 0;
    for (let i = 0; i + 1 < sequence.length; i++) {
        cost += matrix[sequence[i]!]![sequence[i + 1]!]!;
    }
    return cost;
}

async function solve(payload: TspSolveRequest, context: SolverRunContext<TspSolution>): Promise<TspSolution> {
    const mod = await loadModule();
    const requestStart = performance.now();
    const level = payload.vroomExplorationLevel ?? 5;
    const input = buildInput(payload.distanceMatrix, payload.depot);
    const outputJson = runWithAbortReason(mod, "VROOM", () =>
        mod.solveWithTimeout(
            input,
            level,
            VROOM_THREADS,
            vroomTimeoutMs(returningSearchSeconds(context.deadlineAtMs, payload.timeLimitSeconds)),
        ),
    );
    const clientMs = Math.round(performance.now() - requestStart);
    const result = JSON.parse(outputJson) as VroomResult;

    if (result.code != null && result.code !== 0) {
        return emptySolution("ERROR", clientMs, result.error ?? `VROOM error code ${result.code}`);
    }
    const route = result.routes?.[0];
    if (!route) {
        return emptySolution("NO_SOLUTION", clientMs, "VROOM returned no route.");
    }
    const sequence = extractSequence(route);
    if (sequence.length !== payload.distanceMatrix.length + 1) {
        return emptySolution("NO_SOLUTION", clientMs, "VROOM returned an incomplete tour.");
    }
    return {
        // VROOM is a metaheuristic: high-quality tours, no optimality proof.
        status: "FEASIBLE",
        totalCost: recomputeCost(sequence, payload.distanceMatrix),
        wallTimeMs: clientMs,
        clientMs,
        sequence,
    };
}

function emptySolution(status: TspSolution["status"], clientMs: number, error?: string): TspSolution {
    return { status, error, totalCost: 0, wallTimeMs: clientMs, clientMs, sequence: [] };
}

runSolverWorker({ init: loadModule, solve });
