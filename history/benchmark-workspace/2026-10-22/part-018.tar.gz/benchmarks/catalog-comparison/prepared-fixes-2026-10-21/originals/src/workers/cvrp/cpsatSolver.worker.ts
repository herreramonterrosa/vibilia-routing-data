/// <reference lib="webworker" />
import type { DenseMatrix } from "@/lib/denseMatrix";
/**
 * Web Worker that solves CVRP with OR-Tools' CP-SAT through a `routes`
 * constraint (the multi-circuit cousin of TSP's `circuit`).
 *
 * Model:
 *   - One BoolVar `x_ij` per directed arc i → j (i ≠ j).
 *   - One `routes` constraint for the structural multi-circuit (no capacity —
 *     RoutesConstraintProto's `demands`/`capacity` fields are not honoured by
 *     the solver in the OR-Tools version we ship, so capacity is modelled
 *     explicitly).
 *   - One integer `load[v]` per non-depot node, bounded by `[demand[v], capacity]`.
 *   - For each non-depot arc i→j: `x_ij ⇒ load[j] − load[i] = demand[j]`
 *     (linear constraint with `enforcement_literal`).
 *   - For each depot→j arc: `x_0j ⇒ load[j] = demand[j]`.
 *   - One linear constraint `minimumVehicles ≤ Σ x[depot][j] ≤ numVehicles`
 *     bounding the fleet (the optional minimum defaults to zero)
 *     (each used vehicle leaves the depot exactly once).
 *   - Linear objective `Σ matrix[i][j] · x_ij`.
 *
 * CP-SAT's `routes` proto requires the depot to be node 0. If the request's
 * depot is somewhere else we transparently swap rows/columns so the wire
 * format always uses node 0; the resulting tour is mapped back when decoded.
 *
 * The malloc/HEAPU8/free wasm dance is the same as the TSP worker — see
 * compilations/cpsat/instructions.md.
 */
import protobuf from "protobufjs/light";
import protoDescriptor from "@compilations/cpsat/output/protos.json";
import { reportFatalWasmAbort, runSolverWorker, type SolverRunContext } from "../shared/harness";
import { returningSearchSeconds } from "../shared/solveBudget";
import { callCpSat, type CpSatModule } from "../shared/cpsatAbi";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import type { CvrpRoute, CvrpSolution, CvrpSolveRequest, SolveStatus } from "@/types/solver";

interface ProtoTypes {
    CpModelProto: protobuf.Type;
    CpSolverResponse: protobuf.Type;
    SatParameters: protobuf.Type;
}

interface InitState {
    mod: CpSatModule & AbortAwareModule;
    types: ProtoTypes;
}

let initPromise: Promise<InitState> | null = null;

async function init(): Promise<InitState> {
    if (initPromise) return initPromise;
    initPromise = (async () => {
        const root = protobuf.Root.fromJSON(protoDescriptor as protobuf.INamespace);
        const types: ProtoTypes = {
            CpModelProto: root.lookupType("operations_research.sat.CpModelProto"),
            CpSolverResponse: root.lookupType("operations_research.sat.CpSolverResponse"),
            SatParameters: root.lookupType("operations_research.sat.SatParameters"),
        };
        const wasmUrl = `${self.location.origin}/wasm/cp_sat.js`;
        const loader = (await import(/* @vite-ignore */ wasmUrl)) as {
            default: (opts?: Record<string, unknown>) => Promise<CpSatModule>;
        };
        const mod = await loadAbortAwareModule(loader.default, "CP-SAT", reportFatalWasmAbort);
        return { mod, types };
    })();
    return initPromise;
}

interface CvrpModel {
    variables: Array<{ name: string; domain: number[] }>;
    constraints: Array<unknown>;
    objective: { vars: number[]; coeffs: number[] };
    // Maps wire-index back to original matrix index (after the depot-to-0 swap).
    wireToOriginal: number[];
    // The original-index depot. Used by the decoder to label the route starts.
    originalDepot: number;
    // n×n grid of variable indices on the wire (arc i→j ↔ arcVarIdx[i][j]).
    arcVarIdx: number[][];
}

/** Build the model. Internally renames node `payload.depot` → 0 because
 *  RoutesConstraintProto assumes the depot lives at node 0. */
function buildCvrpModel(req: CvrpSolveRequest): CvrpModel {
    const n = req.distanceMatrix.length;

    // Wire indices: 0 := depot, 1..n-1 := the other nodes in their original order
    // with the depot's slot skipped.
    const wireToOriginal: number[] = [req.depot];
    for (let i = 0; i < n; i++) if (i !== req.depot) wireToOriginal.push(i);
    // Reorder demands and look up arcs through the index map. Copying the
    // complete matrix just to move the depot would duplicate n² values.
    const demands: number[] = new Array<number>(n).fill(0);
    for (let i = 0; i < n; i++) {
        demands[i] = Math.max(0, Math.round(req.demands[wireToOriginal[i]!] ?? 0));
    }
    demands[0] = 0; // routes constraint requires the depot's demand to be 0.

    const variables: CvrpModel["variables"] = [];
    const tails: number[] = [];
    const heads: number[] = [];
    const literals: number[] = [];
    const objVars: number[] = [];
    const objCoeffs: number[] = [];
    const arcVarIdx: number[][] = Array.from({ length: n }, () => new Array<number>(n).fill(-1));
    let varIdx = 0;
    for (let i = 0; i < n; i++) {
        const row = req.distanceMatrix[wireToOriginal[i]!]!;
        for (let j = 0; j < n; j++) {
            if (i === j) continue;
            variables.push({ name: `x_${i}_${j}`, domain: [0, 1] });
            tails.push(i);
            heads.push(j);
            literals.push(varIdx);
            objVars.push(varIdx);
            objCoeffs.push(row[wireToOriginal[j]!]!);
            arcVarIdx[i]![j] = varIdx;
            varIdx++;
        }
    }

    // One `load[v]` integer per non-depot node, bounded by [demand, capacity].
    // The load is "cumulative delivery from the depot up to and including v"
    // along whichever sub-route visits v. Bounds enforce per-route capacity.
    const loadVarIdx = new Array<number>(n).fill(-1);
    for (let v = 1; v < n; v++) {
        variables.push({ name: `load_${v}`, domain: [demands[v]!, req.vehicleCapacity] });
        loadVarIdx[v] = varIdx++;
    }

    const constraints: unknown[] = [
        { routes: { tails, heads, literals } },
        // Vehicle cap: each used vehicle leaves the depot exactly once.
        {
            linear: {
                vars: Array.from({ length: n - 1 }, (_, j) => arcVarIdx[0]![j + 1]!),
                coeffs: Array.from({ length: n - 1 }, () => 1),
                domain: [req.minimumVehicles ?? 0, req.numVehicles],
            },
        },
    ];

    // Cumulative load along each route, implied by the arcs that are taken.
    // depot → j: load[j] must equal demand[j]   (constant lower-bound check).
    // i → j (both clients): load[j] − load[i] = demand[j].
    // `enforcementLiteral` lives on the outer ConstraintProto (sibling of `linear`),
    // not inside the LinearConstraintProto.
    for (let j = 1; j < n; j++) {
        constraints.push({
            enforcementLiteral: [arcVarIdx[0]![j]!],
            linear: {
                vars: [loadVarIdx[j]!],
                coeffs: [1],
                domain: [demands[j]!, demands[j]!],
            },
        });
        for (let i = 1; i < n; i++) {
            if (i === j) continue;
            constraints.push({
                enforcementLiteral: [arcVarIdx[i]![j]!],
                linear: {
                    vars: [loadVarIdx[j]!, loadVarIdx[i]!],
                    coeffs: [1, -1],
                    domain: [demands[j]!, demands[j]!],
                },
            });
        }
    }

    return {
        variables,
        constraints,
        objective: { vars: objVars, coeffs: objCoeffs },
        wireToOriginal,
        originalDepot: req.depot,
        arcVarIdx,
    };
}

const STATUS_MAP: Record<number, SolveStatus> = {
    0: "NO_SOLUTION", // UNKNOWN
    1: "ERROR", // MODEL_INVALID
    2: "FEASIBLE", // FEASIBLE
    3: "NO_SOLUTION", // INFEASIBLE
    4: "OPTIMAL", // OPTIMAL
};

interface DecodedResponse {
    status: number;
    solution?: number[];
    objectiveValue?: number;
    wallTime?: number;
}

function inputIssue(payload: CvrpSolveRequest): string | null {
    const n = payload.distanceMatrix.length;
    if (n < 3) return "At least 3 nodes are required.";
    if (payload.depot < 0 || payload.depot >= n) return "Depot index is outside the distance matrix.";
    if (payload.numVehicles < 1) return "At least one vehicle is required.";
    if (
        payload.minimumVehicles !== undefined &&
        (!Number.isSafeInteger(payload.minimumVehicles) ||
            payload.minimumVehicles < 1 ||
            payload.minimumVehicles > Math.min(payload.numVehicles, payload.distanceMatrix.length - 1))
    )
        return "The minimum fleet must fit the available vehicles and customers.";
    if (payload.vehicleCapacity < 1) return "Vehicle capacity must be at least 1.";

    let totalDemand = 0;
    let maxCustomerDemand = 0;
    for (let i = 0; i < n; i++) {
        const demand = i === payload.depot ? 0 : Math.max(0, Math.round(payload.demands[i] ?? 0));
        totalDemand += demand;
        maxCustomerDemand = Math.max(maxCustomerDemand, demand);
    }

    if (maxCustomerDemand > payload.vehicleCapacity) return "A stop demand exceeds vehicle capacity.";
    if (totalDemand > payload.numVehicles * payload.vehicleCapacity) return "Fleet cannot carry the total demand.";
    return null;
}

function reconstructRoutes(model: CvrpModel, solution: number[]): Array<number[]> {
    const n = model.wireToOriginal.length;
    // successor[i] = j   ⇔ arc i → j is in the solution.
    const successor = new Array<number>(n).fill(-1);
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
            if (i === j) continue;
            const v = model.arcVarIdx[i]![j];
            if (v != null && v >= 0 && solution[v] === 1) successor[i] = j;
        }
    }

    // For CVRP the successor of the depot has multiple choices (one per vehicle).
    // We re-scan to collect every depot-outgoing arc that's active.
    const depotOut: number[] = [];
    for (let j = 1; j < n; j++) {
        const v = model.arcVarIdx[0]![j]!;
        if (solution[v] === 1) depotOut.push(j);
    }

    const routes: Array<number[]> = [];
    for (const start of depotOut) {
        const seq: number[] = [model.originalDepot];
        let cur = start;
        for (let step = 0; step < n + 1; step++) {
            seq.push(model.wireToOriginal[cur]!);
            if (cur === 0) break;
            const next = successor[cur];
            if (next == null || next < 0) break;
            cur = next;
        }
        routes.push(seq);
    }
    return routes;
}

function loadOf(seq: number[], demands: number[]): number {
    let load = 0;
    for (const idx of seq) load += demands[idx] ?? 0;
    return load;
}

function distanceOf(seq: number[], matrix: DenseMatrix): number {
    let d = 0;
    for (let i = 0; i + 1 < seq.length; i++) d += matrix[seq[i]!]![seq[i + 1]!]!;
    return d;
}

function empty(status: CvrpSolution["status"], clientMs: number, error?: string, wallTimeMs = clientMs): CvrpSolution {
    return { status, error, totalCost: 0, wallTimeMs, clientMs, routes: [], dropped: [] };
}

async function solve(payload: CvrpSolveRequest, context: SolverRunContext<CvrpSolution>): Promise<CvrpSolution> {
    const requestStart = performance.now();
    const issue = inputIssue(payload);
    if (issue) return empty("NO_SOLUTION", Math.round(performance.now() - requestStart), issue, 0);

    const { mod, types } = await init();

    const model = buildCvrpModel(payload);
    const modelMsg = types.CpModelProto.create({
        variables: model.variables,
        constraints: model.constraints,
        objective: model.objective,
    });
    const reqBytes = types.CpModelProto.encode(modelMsg).finish();

    const paramsMsg = types.SatParameters.create({
        maxTimeInSeconds: returningSearchSeconds(context.deadlineAtMs, payload.timeLimitSeconds),
        // The committed CP-SAT module is non-threaded so it can share the
        // OR-Tools archive with Routing.
        numWorkers: 1,
    });
    const paramBytes = types.SatParameters.encode(paramsMsg).finish();

    const resBytes = runWithAbortReason(mod, "CP-SAT", () => callCpSat(mod, reqBytes, paramBytes));

    const decoded = types.CpSolverResponse.decode(resBytes);
    const obj = types.CpSolverResponse.toObject(decoded, {
        longs: Number,
        enums: Number,
        defaults: true,
    }) as DecodedResponse;

    const status = STATUS_MAP[obj.status] ?? "ERROR";
    const wallTimeMs = Math.round((obj.wallTime ?? 0) * 1000);
    const clientMs = Math.round(performance.now() - requestStart);

    if (status === "ERROR" || status === "NO_SOLUTION" || !obj.solution) {
        return empty(status, clientMs, status === "ERROR" ? "CP-SAT rejected the CVRP model." : undefined, wallTimeMs);
    }

    const rawRoutes = reconstructRoutes(model, obj.solution);
    const routes: CvrpRoute[] = rawRoutes.map((sequence, i) => ({
        vehicle: i,
        sequence,
        distance: distanceOf(sequence, payload.distanceMatrix),
        load: loadOf(sequence, payload.demands),
    }));
    return {
        status,
        totalCost: routes.reduce((s, r) => s + r.distance, 0),
        wallTimeMs,
        clientMs,
        routes,
        dropped: [],
    };
}

runSolverWorker({ init: init, solve });
