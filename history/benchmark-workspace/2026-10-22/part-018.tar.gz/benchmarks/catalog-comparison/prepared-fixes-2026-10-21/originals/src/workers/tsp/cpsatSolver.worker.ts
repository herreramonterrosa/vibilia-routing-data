/// <reference lib="webworker" />
/**
 * Web Worker that loads the CP-SAT WASM module and solves TSP via a `circuit`
 * constraint.
 *
 * Model:
 *   - N nodes → N*(N-1) BoolVars `x_ij`, one literal per directed arc i→j (i≠j).
 *   - One `CircuitConstraint(tails=[i...], heads=[j...], literals=[var_ij...])`.
 *   - Objective: minimize Σ dist_ij · x_ij.
 *
 * The host communicates with this worker through the typed message protocol
 * defined in `shared/tsp-messages.ts`. The malloc/HEAPU8/free pattern below is
 * documented in `compilations/cpsat/instructions.md`.
 */
// `protobufjs/light` excludes the .proto text parser (and its fs lookup) which
// Vite externalizes and warns about in browser builds. We pre-compile the .proto
// files to a JSON descriptor at build time (see compilations/cpsat/build.sh) and
// hydrate it here with Root.fromJSON.
import protobuf from "protobufjs/light";
import protoDescriptor from "@compilations/cpsat/output/protos.json";
import { reportFatalWasmAbort, runSolverWorker, type SolverRunContext } from "../shared/harness";
import { returningSearchSeconds } from "../shared/solveBudget";
import { callCpSat, type CpSatModule } from "../shared/cpsatAbi";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import type { SolveStatus, TspSolution, TspSolveRequest } from "@/types/solver";

interface ProtoTypes {
    CpModelProto: protobuf.Type;
    CpSolverResponse: protobuf.Type;
    SatParameters: protobuf.Type;
}

interface InitState {
    mod: CpSatModule & AbortAwareModule;
    types: ProtoTypes;
}

let initPromise: Promise<InitState> | null = null;

async function init(): Promise<InitState> {
    if (initPromise) return initPromise;
    initPromise = (async () => {
        const root = protobuf.Root.fromJSON(protoDescriptor as protobuf.INamespace);
        const types: ProtoTypes = {
            CpModelProto: root.lookupType("operations_research.sat.CpModelProto"),
            CpSolverResponse: root.lookupType("operations_research.sat.CpSolverResponse"),
            SatParameters: root.lookupType("operations_research.sat.SatParameters"),
        };

        const wasmUrl = `${self.location.origin}/wasm/cp_sat.js`;
        const loader = (await import(/* @vite-ignore */ wasmUrl)) as {
            default: (opts?: Record<string, unknown>) => Promise<CpSatModule>;
        };
        const mod = await loadAbortAwareModule(loader.default, "CP-SAT", reportFatalWasmAbort);
        return { mod, types };
    })();
    return initPromise;
}

interface TspModel {
    variables: Array<{ name: string; domain: number[] }>;
    constraints: Array<{ circuit: { tails: number[]; heads: number[]; literals: number[] } }>;
    objective: { vars: number[]; coeffs: number[] };
}

/** Builds the flat CpModelProto for TSP: one BoolVar per directed arc, a `circuit`
 *  constraint over all arcs, and a linear objective Σ dist_ij · x_ij. */
function buildTspModel(req: TspSolveRequest): TspModel {
    const n = req.distanceMatrix.length;
    const variables: TspModel["variables"] = [];
    const tails: number[] = [];
    const heads: number[] = [];
    const literals: number[] = [];
    const objVars: number[] = [];
    const objCoeffs: number[] = [];
    let varIdx = 0;
    for (let i = 0; i < n; i++) {
        const row = req.distanceMatrix[i]!;
        for (let j = 0; j < n; j++) {
            if (i === j) continue;
            variables.push({ name: `x_${i}_${j}`, domain: [0, 1] });
            tails.push(i);
            heads.push(j);
            literals.push(varIdx);
            objVars.push(varIdx);
            objCoeffs.push(row[j]!);
            varIdx++;
        }
    }
    return {
        variables,
        constraints: [{ circuit: { tails, heads, literals } }],
        objective: { vars: objVars, coeffs: objCoeffs },
    };
}

const STATUS_MAP: Record<number, SolveStatus> = {
    0: "NO_SOLUTION", // UNKNOWN
    1: "ERROR", // MODEL_INVALID
    2: "FEASIBLE", // FEASIBLE
    3: "NO_SOLUTION", // INFEASIBLE
    4: "OPTIMAL", // OPTIMAL
};

interface DecodedResponse {
    status: number;
    solution?: number[];
    objectiveValue?: number;
    wallTime?: number;
}

/** Rebuilds the visit sequence by following arcs with value 1, starting from the depot. */
function reconstructSequence(req: TspSolveRequest, solution: number[]): number[] {
    const n = req.distanceMatrix.length;
    const successor = new Array<number>(n).fill(-1);
    let varIdx = 0;
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
            if (i === j) continue;
            if (solution[varIdx] === 1) successor[i] = j;
            varIdx++;
        }
    }

    const seq: number[] = [req.depot];
    let cur = req.depot;
    for (let step = 0; step < n; step++) {
        const next = successor[cur];
        if (next == null || next < 0) break;
        seq.push(next);
        if (next === req.depot) break;
        cur = next;
    }
    return seq;
}

async function solve(payload: TspSolveRequest, context: SolverRunContext<TspSolution>): Promise<TspSolution> {
    const { mod, types } = await init();
    const requestStart = performance.now();

    const modelObj = buildTspModel(payload);
    const modelMsg = types.CpModelProto.create(modelObj);
    const reqBytes = types.CpModelProto.encode(modelMsg).finish();

    const paramsMsg = types.SatParameters.create({
        maxTimeInSeconds: returningSearchSeconds(context.deadlineAtMs, payload.timeLimitSeconds),
        // The committed CP-SAT module shares the non-threaded OR-Tools archive
        // with Routing. One search worker avoids spawning unavailable pthreads.
        numWorkers: 1,
    });
    const paramBytes = types.SatParameters.encode(paramsMsg).finish();

    const resBytes = runWithAbortReason(mod, "CP-SAT", () => callCpSat(mod, reqBytes, paramBytes));

    const decoded = types.CpSolverResponse.decode(resBytes);
    const obj = types.CpSolverResponse.toObject(decoded, {
        longs: Number,
        enums: Number,
        defaults: true,
    }) as DecodedResponse;

    const status = STATUS_MAP[obj.status] ?? "ERROR";
    const wallTimeMs = Math.round((obj.wallTime ?? 0) * 1000);
    const clientMs = Math.round(performance.now() - requestStart);

    if (status === "ERROR" || status === "NO_SOLUTION" || !obj.solution) {
        return { status, totalCost: 0, wallTimeMs, clientMs, sequence: [] };
    }

    return {
        status,
        totalCost: Math.round(obj.objectiveValue ?? 0),
        wallTimeMs,
        clientMs,
        sequence: reconstructSequence(payload, obj.solution),
    };
}

runSolverWorker({ init: init, solve });
