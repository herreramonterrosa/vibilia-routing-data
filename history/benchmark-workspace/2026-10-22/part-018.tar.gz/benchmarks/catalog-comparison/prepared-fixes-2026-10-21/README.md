Correcciones preparadas el 21 de octubre de 2026 para CP-SAT y VROOM.

Estado actualizado: aplicadas el 21 de octubre de 2026 a las 11:44 de Bogotá, después del cierre del lote anterior. `application.json` registra los 12 archivos instalados y `activation-before.json` conserva los hashes de sus 4.719 observaciones y los 3.579 resultados válidos. La comprobación global de tipos pasó después de aplicar. El manifiesto y `preservation.json` conservan la evidencia de la preparación anterior; la copia aislada está en `compilations/.build/catalog-second-pass-2026-10-21/workspace`.

Primer reintento real, cohorte `a38cd2c7548776b17e70cd1dacdc4918bd4a83ebf13af636cb732a879334b842`: XL-n3334-k934 mantuvo 934 vehículos mínimos/máximos, capacidad 20, redondeo original y 60 segundos totales. CP-SAT terminó en 5,746 s como `resource_limit` (antes sufría un corte externo a 61,018 s). VROOM terminó en 3,287 s como error técnico: `Native abort without diagnostics.` Ninguno obtuvo una solución válida; el fallo nativo de VROOM sigue sin causa identificada. Ambas observaciones quedan guardadas y el mismo libro de reintentos evita ejecutarlas otra vez al ampliar la pasada a los demás fallos.

El nuevo plan filtrado recuperó las 4.719 observaciones. Se revisó mediante el arnés canónico la exclusión de jsprit en ORTEC-VRPTW-ASYM-00c5356f-d1-n258-k12: su matriz es asimétrica y la integración exige simetría. Esa consulta terminó antes de iniciar un motor y restauró la cobertura de 832 escenarios sin repetir ninguna solución.

La continuación para todos los fallos de CP-SAT/VROOM arrancó a las 11:48 de Bogotá con los mismos hashes y presupuestos y terminó el 21 de octubre a las 12:23. Completó los 170 reintentos de 132 escenarios, sin obtener soluciones nuevas. Los 132 fallos de CP-SAT terminaron como límites de recursos: 93 antes sufrían un corte externo y 39 ya eran límites de recursos. VROOM conserva 20 abortos sin diagnóstico y 18 límites de recursos. No quedan reintentos en cola; los 170 intentos siguen sin solución.

`second-pass-complete-audit.json` registra la comprobación final: los 4.719 archivos originales permanecen sin cambios, los 3.579 resultados válidos se conservan con procedencia y ninguno se ha repetido. Cada fallo seleccionado tuvo un único reintento en esta cohorte. Los 156 archivos congelados coinciden con sus hashes y la auditoría no muestra discrepancias de soluciones, fuentes o tiempos. La cobertura se mantiene en 832 escenarios y 4.719 comparaciones. Se necesita una corrección adicional de los límites de recursos o de los abortos nativos para justificar otra pasada; no se ha iniciado una repetición automática.

CP-SAT construía un grafo de objetos JavaScript, nombres de variables y una matriz adicional de índices antes de consultar el tiempo restante. La versión preparada escribe directamente el modelo protobuf en un único buffer de tamaño calculado, sin ese grafo ni esa matriz. Comprueba el plazo durante las pasadas de construcción, antes/después de asignar memoria y antes de decodificar. Una preparación que agota el tiempo devuelve ausencia de solución dentro del presupuesto, sin afirmar inviabilidad. Los fallos reales de asignación siguen clasificados como recursos.

El modelo conserva circuito/rutas, flota mínima y máxima, capacidad, depósito, objetivo y normalización original de demandas. Solo se eliminan arcos entre clientes cuya demanda conjunta excede la capacidad. En XL-n3334-k934 esto no elimina ninguno: conserva los 11.112.222 arcos. Los únicos nuevos límites representacionales son los de la API nativa: longitud de entrada e índices de 32 bits; no hay umbral de nodos. El parseo C++ y la decodificación de la respuesta siguen siendo síncronos, por lo que permanece el corte externo. Los registros antiguos no permiten atribuir todos los cortes a una fase concreta; falta medir el resultado del cambio en el motor real.

La observación guardada de VROOM en XL-n3334-k934 terminó tras 3367,565 ms con `VROOM aborted: `, sin diagnóstico. No demuestra falta de memoria ni desbordamiento de pila. La versión preparada conserva hasta 16 líneas de stderr de 512 caracteres cada una cuando el aborto no trae motivo. Mantiene el mensaje tras el desenrollado de un hilo, evita reutilizar diagnósticos de la ejecución anterior y prioriza un motivo nativo concreto. Un aborto todavía vacío sigue siendo un error técnico. No se han cambiado el binario, los cuatro hilos ni las restricciones. Este cambio corrige la pérdida de información; aún no demuestra que VROOM resuelva esa instancia.

Validación realizada: 30 pruebas CP-SAT (descriptor oficial, 192 particiones/permutaciones CVRP, límites protobuf y de la API, reloj simulado, normalización y clasificación de memoria), 12 pruebas de aborto/adaptadores/compatibilidad CLI, ESLint de los archivos preparados y comprobación TypeScript de los diez archivos modificados. No se ejecutaron motores nativos ni escenarios del catálogo durante la preparación. La sintaxis del aplicador se comprobó y su modo de revisión bloquea la activación mientras el lote sigue vivo.

Para activar después, ejecutar desde `/home/sj_/projects/vibilia-routing`, con el Node y Chromium actuales. El supervisor vigente pasa automáticamente de pendientes a reintentos y no tiene pausa entre ambas fases. Dejar terminar su invocación completa evita interrumpir una medición. No sustituir archivos con ese proceso vivo ni borrar informes, registros o libros de reintentos.

```bash
node scripts/run-catalog-comparisons.mjs --status
node benchmarks/catalog-comparison/prepared-fixes-2026-10-21/apply-prepared.mjs --check
```

Solo cuando ambos procesos hayan terminado y la revisión indique `ready: true`:

```bash
node benchmarks/catalog-comparison/prepared-fixes-2026-10-21/apply-prepared.mjs --apply
```

El aplicador comprueba los hashes, exige que no queden pendientes ni una medición activa, usa el mismo bloqueo exclusivo del supervisor y guarda los originales. No detiene procesos ni inicia motores. Si los archivos cambiaron desde la preparación, hay que revisar y regenerar el paquete; no forzar su aplicación. No hace falta recompilar WASM para estos cambios.

La primera medición real será el reintento canónico de XL-n3334-k934, con su flota exacta de 934 vehículos, capacidad 20, redondeo al entero más próximo y 60 segundos totales, incluida la inicialización. No se modifica la política de tiempo ni las restricciones. La fuente debe conservar SHA-256 `a7989aa04bb37221dbfd7ac127bcc709d9df055344c01277c2be1fc2a39c2bb2`.

```bash
env -u CATALOG_COMPARISON_BUDGET_SECONDS \
  PATH=/home/sj_/.nvm/versions/node/v24.18.1/bin:/usr/bin:/bin \
  LD_LIBRARY_PATH=/home/sj_/.cache/opt-in-the-browser/playwright-deps/ubuntu-24.04-amd64/root/usr/lib/x86_64-linux-gnu \
  CATALOG_COMPARISON_LABEL=catalog-2026-10-21-second-pass \
  CATALOG_COMPARISON_METHODS=cpsat,vroom \
  CATALOG_COMPARISON_IDS=cvrplib-xl-xl-n3334-k934 \
  node scripts/run-catalog-comparisons.mjs --background
```

Cuando termine ese comando en segundo plano, revisar sus registros y auditoría. Si alguno de los dos motores ya tiene un resultado válido guardado, se reutiliza y no se vuelve a ejecutar. Los nuevos hashes crean una cohorte que permite reintentar fallos técnicos anteriores y conserva la procedencia de todas las observaciones recuperadas. Cambiar solamente la etiqueta no basta para habilitar un reintento ya terminado con los mismos hashes.

Después, con los mismos archivos, entorno y etiqueta, ampliar a los restantes fallos de esos motores:

```bash
env -u CATALOG_COMPARISON_BUDGET_SECONDS -u CATALOG_COMPARISON_IDS \
  PATH=/home/sj_/.nvm/versions/node/v24.18.1/bin:/usr/bin:/bin \
  LD_LIBRARY_PATH=/home/sj_/.cache/opt-in-the-browser/playwright-deps/ubuntu-24.04-amd64/root/usr/lib/x86_64-linux-gnu \
  CATALOG_COMPARISON_LABEL=catalog-2026-10-21-second-pass \
  CATALOG_COMPARISON_METHODS=cpsat,vroom \
  node scripts/run-catalog-comparisons.mjs --background
```

La medición de XL ya guardada queda omitida en esta continuación. También se omiten las soluciones válidas y búsquedas correctamente terminadas sin solución. Si VROOM vuelve a abortar, el motivo recogido guiará una corrección nativa concreta; no reclasificarlo como memoria sin evidencia. El diagnóstico Node opcional `benchmarks/catalog-comparison/vroom-abort-diagnostic.mjs` es solo para esa investigación adicional, no sustituye una comparación en navegador ni se ejecuta mientras el catálogo siga vivo.
