/** Preserve Emscripten's abort reason before its final WASM trap loses it. */
export interface AbortAwareModule {
    takeAbortReason: () => string | undefined;
    resetAbortDiagnostics?: () => void;
}

/** Emscripten unwound a parent pthread join to deliver a child abort on the
 * worker event loop. The later onAbort/worker-error event is authoritative. */
export class WasmAbortPending extends Error {
    constructor() {
        super("Waiting for a native child-thread abort event.");
        this.name = "WasmAbortPending";
    }
}

export type FatalAbortReporter = (engine: string, reason: string) => void;

export async function loadAbortAwareModule<T extends object>(
    factory: (options?: Record<string, unknown>) => Promise<T>,
    engine: string,
    reportFatalAbort?: FatalAbortReporter,
    options: { captureStderr?: boolean } = {},
): Promise<T & AbortAwareModule> {
    let abortReason: string | undefined;
    const stderr: string[] = [];
    try {
        const module = await factory({
            ...(options.captureStderr
                ? {
                      printErr: (value: unknown) => {
                          // C abort()/std::terminate can call onAbort("") after
                          // libc++ prints the only useful diagnosis on stderr.
                          // Bound retained diagnostics independently of input size.
                          stderr.push(String(value).slice(0, 512));
                          if (stderr.length > 16) stderr.shift();
                          console.error(value);
                      },
                  }
                : {}),
            onAbort: (reason: unknown) => {
                const nativeReason = reason == null ? "" : String(reason).trim();
                abortReason =
                    nativeReason ||
                    stderr.filter((line) => line.trim()).join("\n") ||
                    "Native abort without diagnostics.";
                try {
                    reportFatalAbort?.(engine, abortReason);
                } catch {
                    // Preserve the native abort reason even if posting its
                    // immediate host notification unexpectedly fails.
                }
            },
        });
        return Object.assign(module, {
            resetAbortDiagnostics: () => {
                stderr.length = 0;
            },
            takeAbortReason: () => {
                const reason = abortReason;
                abortReason = undefined;
                return reason;
            },
        });
    } catch (cause) {
        if (abortReason) throw new Error(`${engine} aborted during initialization: ${abortReason}`, { cause });
        throw cause;
    }
}

export function runWithAbortReason<T>(module: AbortAwareModule, engine: string, run: () => T): T {
    module.takeAbortReason();
    module.resetAbortDiagnostics?.();
    try {
        return run();
    } catch (cause) {
        const reason = module.takeAbortReason();
        if (reason) throw new Error(`${engine} aborted: ${reason}`, { cause });
        if (cause === "unwind") throw new WasmAbortPending();
        throw cause;
    }
}
