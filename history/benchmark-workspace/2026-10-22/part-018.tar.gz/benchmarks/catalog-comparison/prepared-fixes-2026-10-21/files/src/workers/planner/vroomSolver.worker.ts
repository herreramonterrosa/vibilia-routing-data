/// <reference lib="webworker" />
/**
 * Planner Web Worker over the VROOM wasm module (same binary the Lab uses).
 *
 * Unlike the Lab's CVRPTW worker, this one speaks the planner wire format
 * (src/planner/engines/wire.ts) and maps it onto VROOM's native model, which
 * covers the heterogeneous features directly: per-vehicle capacity/shift/
 * caps/fixed costs, skills, priorities and multiple time windows per job.
 * Strict required visits and total route-duration caps are rejected because
 * VROOM cannot enforce those semantics.
 */
import { reportFatalWasmAbort, runSolverWorker } from "../shared/harness";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import {
    buildVroomInput,
    routeFromVroom,
    vroomExplorationLevel,
    vroomThreadCount,
    vroomTimeoutMs,
    type VroomOutput,
} from "@/planner/engines/vroomAdapter";
import type { PlannerSolveRequest, PlannerWireSolution, WireRoute } from "@/planner/engines/wire";

interface VroomModule {
    solveWithTimeout: (inputJson: string, explorationLevel: number, nbThreads: number, timeoutMs: number) => string;
    version: () => string;
}

type VroomFactory = (opts?: Record<string, unknown>) => Promise<VroomModule>;

let modulePromise: Promise<VroomModule & AbortAwareModule> | null = null;

async function loadModule(): Promise<VroomModule & AbortAwareModule> {
    if (modulePromise) return modulePromise;
    modulePromise = (async () => {
        const url = new URL("/wasm/vroom.js", self.location.origin).toString();
        const mod = (await import(/* @vite-ignore */ url)) as { default: VroomFactory };
        return loadAbortAwareModule(mod.default, "VROOM", reportFatalWasmAbort, { captureStderr: true });
    })();
    return modulePromise;
}

async function solve(payload: PlannerSolveRequest): Promise<PlannerWireSolution> {
    const level = vroomExplorationLevel(payload.vroomExplorationLevel);
    const threads = vroomThreadCount(payload.vroomThreads);
    const input = buildVroomInput(payload);
    const mod = await loadModule();
    const requestStart = performance.now();
    const outJson = runWithAbortReason(mod, "VROOM", () =>
        mod.solveWithTimeout(input, level, threads, vroomTimeoutMs(payload.timeLimitSeconds)),
    );
    const clientMs = Math.round(performance.now() - requestStart);
    const result = JSON.parse(outJson) as VroomOutput;

    if (result.code != null && result.code !== 0) {
        return {
            status: "ERROR",
            error: result.error ?? `VROOM error code ${result.code}`,
            totalCost: 0,
            wallTimeMs: clientMs,
            clientMs,
            routes: [],
            dropped: [],
        };
    }

    const routes = (result.routes ?? [])
        .map((r) => routeFromVroom(r, payload))
        .filter((r): r is WireRoute => r !== null);
    const dropped = (result.unassigned ?? []).map((u) => u.location_index).filter((idx): idx is number => idx != null);

    return {
        status: "FEASIBLE",
        totalCost: routes.reduce((sum, r) => sum + r.distance, 0),
        wallTimeMs: clientMs,
        clientMs,
        routes,
        dropped,
    };
}

runSolverWorker({ init: loadModule, solve });
