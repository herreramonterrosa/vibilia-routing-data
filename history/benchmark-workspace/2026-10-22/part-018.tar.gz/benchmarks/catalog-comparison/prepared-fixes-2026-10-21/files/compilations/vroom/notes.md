# VROOM WASM build notes

The pinned source lives in `compilations/.deps/vroom-upstream.git`; each build
uses a temporary worktree. Compiled objects live under
`compilations/.build/vroom/<build-key>/`. The key includes the source tree,
submodule heads, local wrapper and patch, compiler version, and flags.

The current build keeps VROOM's pthread search. The Emscripten module prestarts
eight pool workers (`PTHREAD_POOL_SIZE=8`), while application calls request four
threads per solve by default (internal Planner benchmarks can request 1–8).
Upstream launches one pthread for every search rank before its semaphore can
throttle work: exploration level 5 produces 32 ranks. Patch
`0003-bounded-search-threads.patch` uses a bounded worker loop to run all ranks
with at most the requested number of threads, so the eight-worker pool covers
the maximum accepted request. Pool workers must exist before VROOM enters its
blocking search; otherwise `pthread_create` may deadlock while the caller waits
for a new worker. The module uses shared memory, so deployments need cross-origin
isolation (COOP/COEP). The repository's Vite configuration supplies those
headers for local development.

`-fwasm-exceptions` enables caught errors in the C++ wrapper.
`-fexperimental-library` makes the required libc++ threading types available.
`0002-wasm-libcxx-dedupe.patch` removes duplicate explicit template
instantiations caused by libc++ iterator aliases. The old sequential patch is
kept only for reference. Sources for the CLI, remote routing, and GLPK checks
are excluded from the browser build.

VROOM is a metaheuristic and the application reports `FEASIBLE`, not an
optimality proof. Its native timeout can stop search with the best solution
found so far. The wrapper rejects exploration values outside 0–5 and negative
timeouts as JSON errors, then remains usable for later calls.

## P-n55-k15 incomplete search (2026-10-18)

The unchanged shipped module reproduces the catalog's partial result with 15
vehicles of capacity 70, exploration level 5 and four search threads. Total
demand is 1042 against 1050 available capacity. It explicitly returns customer
index 11 (source ID 12, demand 37) in `unassigned`; all 15 returned routes obey
capacity, but their free space is fragmented. This is a heuristic result without
a complete incumbent, not an infeasibility proof or an adapter losing a visit.

A native diagnostic with a 10-second total budget, including module loading,
finished in about 1.52 seconds with that partial result. Sorting jobs by demand
without changing IDs, priorities or costs also left this customer unassigned;
the application keeps its original input order. No capacities, vehicle counts,
priorities, objectives or binaries were changed to make this instance pass.
The partial travel cost must not be compared with the full benchmark optimum.

`PARTIAL_NATIVE_REGRESSION=1` enables
`src/workers/shared/__tests__/partialNativeRegression.spec.ts`. It runs each
engine in an externally bounded subprocess, checks native unassigned IDs
against independent route coverage, and rejects any extra constraint failure.
The source hash is
`9ffe8a99263ee459960db909fb61651a66f86815a1781f17140812119596bad4`.

## Deferred large-instance abort investigation (2026-10-21)

The saved `XL-n3334-k934` observation failed after 3367.565 ms with
`VROOM aborted: ` and no native diagnostic. It used the original 3334 nodes,
934 available and required routes, capacity 20, nearest Euclidean rounding,
and a 60-second total budget. `Antwerp1` showed the same empty abort after
8031.505 ms with 6001 nodes, 343 available vehicles and capacity 30.

The pinned generated module calls `onAbort("")` for C `abort()`, while heap
growth failure sends `OOM` and failed assertions include their expression.
The saved empty string therefore does not establish a memory or stack cause.
The native CVRP search-worker and matrix-worker bodies already capture all
exceptions and rethrow them on the caller; the wrapper catches native standard
exceptions. No missing catch has been established for these observations.

The prepared adapter change opts into a bounded stderr tail (16 lines, at most
512 characters each). It preserves libc++ diagnostics when an abort has no
payload, including a delayed child-thread abort delivered after `unwind`.
Concrete native abort reasons take precedence; stale diagnostics are cleared
before each solve. An empty abort without stderr remains a technical error,
not a guessed resource limit. The native binary, thread count, fleet,
constraints, costs and timing budget are unchanged.

The first validation after activating this change should use the existing
catalog browser harness, filtered to failed VROOM/CP-SAT arms of
`cvrplib-xl-xl-n3334-k934`, with the same 60-second policy and recovery enabled.
Its stored observation is then reusable by the remaining second pass; there
is no need to run the same real case twice. The optional
`benchmarks/catalog-comparison/vroom-abort-diagnostic.mjs` is reserved for
additional native investigation if the browser observation still fails. It
requires `RUN_VROOM_ABORT_DIAGNOSTIC=1`, refuses while a catalog process is
alive (including when invoked from the staging directory), bounds the child
process externally, hashes the original source and module, and never writes
comparison records. It is a Node diagnostic, not a browser benchmark.

Only lightweight adapter/error-handling tests and the guard were run while
pending measurements continued. These changes fix lost diagnostics; they do
not yet demonstrate that either large instance solves successfully.
