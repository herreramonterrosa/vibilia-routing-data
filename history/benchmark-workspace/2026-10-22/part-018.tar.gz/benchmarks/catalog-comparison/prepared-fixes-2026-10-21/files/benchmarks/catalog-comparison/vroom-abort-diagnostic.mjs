/** Opt-in native diagnostics; never publishes or replaces catalog measurements.
 * Run only after the pending catalog has stopped: RUN_VROOM_ABORT_DIAGNOSTIC=1
 * node benchmarks/catalog-comparison/vroom-abort-diagnostic.mjs [XL-n3334-k934|Antwerp1]
 * The canonical browser harness remains required for comparative results.
 */
import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, readFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createServer } from "vite";

const root = fileURLToPath(new URL("../../", import.meta.url));
const child = process.argv[2] === "--child";
const name = process.argv[child ? 3 : 2] ?? "XL-n3334-k934";
const cases = {
    "XL-n3334-k934": {
        sourceSha256: "a7989aa04bb37221dbfd7ac127bcc709d9df055344c01277c2be1fc2a39c2bb2",
        dimension: 3334,
        vehicles: 934,
        minimumVehicles: 934,
        capacity: 20,
    },
    Antwerp1: {
        sourceSha256: "3c5c9237554dd17bc0fd1d5da38ed7b63881ab02845de6618f6cac05abe6d4aa",
        dimension: 6001,
        vehicles: 343,
        minimumVehicles: 1,
        capacity: 30,
    },
};
if (process.env.RUN_VROOM_ABORT_DIAGNOSTIC !== "1") throw new Error("Set RUN_VROOM_ABORT_DIAGNOSTIC=1 explicitly.");
if (!Object.hasOwn(cases, name)) throw new Error(`Unsupported diagnostic case: ${name}`);
// Also inspect ancestors so running from the isolated staging directory cannot
// accidentally compete with the live root catalog. EPERM means alive/unknown.
for (let directory = root; ; directory = dirname(directory)) {
    const execution = resolve(directory, "benchmarks/catalog-comparison/execution.json");
    if (existsSync(execution)) {
        const state = JSON.parse(readFileSync(execution, "utf8"));
        for (const pid of [state.pid, state.childPid]) {
            if (!Number.isSafeInteger(pid) || pid <= 0) continue;
            try {
                process.kill(pid, 0);
            } catch (error) {
                if (error.code === "ESRCH") continue;
                throw error;
            }
            throw new Error(`Catalog process ${pid} is alive; deferred VROOM diagnostics must wait.`);
        }
    }
    if (dirname(directory) === directory) break;
}

if (!child) {
    const probe = spawn(process.execPath, [fileURLToPath(import.meta.url), "--child", name], {
        stdio: ["ignore", "inherit", "inherit", "ipc"],
    });
    let expired = false;
    // Import/validation tooling is outside the solve budget, but externally bounded.
    let timer = setTimeout(() => {
        expired = true;
        probe.kill("SIGKILL");
    }, 30_000);
    probe.on("message", (message) => {
        if (message?.stage !== "solve-started") return;
        clearTimeout(timer);
        timer = setTimeout(() => {
            expired = true;
            probe.kill("SIGKILL");
        }, 61_000);
    });
    probe.on("error", (error) => {
        clearTimeout(timer);
        console.error(error);
        process.exitCode = 1;
    });
    probe.on("exit", (code, signal) => {
        clearTimeout(timer);
        if (expired)
            console.error(JSON.stringify({ name, outcome: "external_cutoff", budgetSeconds: 60, marginMs: 1000 }));
        process.exitCode = expired || signal ? 1 : (code ?? 1);
    });
} else {
    const evidence = cases[name];
    const source = readFileSync(resolve(root, `benchmarks/catalog-comparison/sources/${evidence.sourceSha256}.txt`));
    if (createHash("sha256").update(source).digest("hex") !== evidence.sourceSha256)
        throw new Error("Source hash mismatch.");
    const server = await createServer({
        root,
        configFile: false,
        cacheDir: resolve(root, ".cache/vroom-abort-diagnostic"),
        resolve: { alias: { "@": resolve(root, "src") } },
        server: { middlewareMode: true, hmr: false, watch: null },
        appType: "custom",
    });
    let parseInstance, validateInstanceSolution, loadAbortAwareModule, runWithAbortReason;
    try {
        ({ parseInstance } = await server.ssrLoadModule("/src/lab/instances/parser.ts"));
        ({ validateInstanceSolution } = await server.ssrLoadModule("/src/lab/instances/validateSolution.ts"));
        ({ loadAbortAwareModule, runWithAbortReason } = await server.ssrLoadModule("/src/workers/shared/wasmAbort.ts"));
    } finally {
        await server.close();
    }
    const instance = {
        ...parseInstance(source.toString("utf8"), { euclideanRounding: "nearest" }),
        minimumVehicles: evidence.minimumVehicles,
    };
    if (
        instance.dimension !== evidence.dimension ||
        instance.capacity !== evidence.capacity ||
        instance.profile !== "vrplib:EUC_2D:nearest:distance"
    )
        throw new Error("Original instance restrictions changed.");
    const wasmSha256 = createHash("sha256")
        .update(readFileSync(resolve(root, "public/wasm/vroom.wasm")))
        .digest("hex");
    const started = performance.now();
    process.send?.({ stage: "solve-started" });
    let fatalReason;
    let releaseAbort;
    const aborted = new Promise((resolveAbort) => {
        releaseAbort = resolveAbort;
    });
    const result = {
        name,
        ...evidence,
        wasmSha256,
        runtime: process.version,
        budgetSeconds: 60,
        diagnosticOnly: true,
        measuredAt: new Date().toISOString(),
    };
    try {
        const { default: factory } = await import(pathToFileURL(resolve(root, "public/wasm/vroom.js")).href);
        const mod = await loadAbortAwareModule(
            factory,
            "VROOM",
            (_engine, reason) => {
                fatalReason = reason;
                releaseAbort(reason);
            },
            { captureStderr: true },
        );
        const input = JSON.stringify({
            vehicles: Array.from({ length: evidence.vehicles }, (_, id) => ({
                id,
                start_index: instance.depot,
                end_index: instance.depot,
                capacity: [evidence.capacity],
            })),
            jobs: instance.demands.flatMap((demand, id) =>
                id === instance.depot ? [] : [{ id, location_index: id, delivery: [demand] }],
            ),
            matrices: { car: { durations: instance.distanceMatrix.map((row) => ({ toJSON: () => Array.from(row) })) } },
        });
        const remainingMs = Math.floor(59_750 - (performance.now() - started));
        if (remainingMs <= 0) throw new Error("Time budget exhausted during initialization and input preparation.");
        const raw = JSON.parse(runWithAbortReason(mod, "VROOM", () => mod.solveWithTimeout(input, 5, 4, remainingMs)));
        if (raw.code) throw new Error(raw.error ?? `VROOM native error ${raw.code}`);
        const routes = (raw.routes ?? []).map((route) => ({
            vehicle: route.vehicle,
            sequence: route.steps.map((step) => step.location_index),
        }));
        const validation = validateInstanceSolution(instance, routes, { vehicles: evidence.vehicles });
        const elapsedMs = performance.now() - started;
        Object.assign(result, {
            outcome: validation.valid && elapsedMs <= 60_000 ? "feasible" : "not_accepted",
            elapsedMs,
            validation,
            unassigned: raw.unassigned,
            routes,
        });
    } catch (error) {
        if (error?.name === "WasmAbortPending") await aborted;
        Object.assign(result, {
            outcome: "error",
            elapsedMs: performance.now() - started,
            reason: fatalReason ?? String(error),
        });
    }
    console.log(JSON.stringify(result));
    // Explicitly release the eight idle native pthread workers.
    process.exit(result.outcome === "error" ? 2 : 0);
}
