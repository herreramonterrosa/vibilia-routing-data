import { afterEach, describe, expect, it, vi } from "vitest";
import protobuf from "protobufjs/light";
import descriptor from "../../../../compilations/cpsat/output/protos.json";
import type { CvrpSolveRequest, TspSolveRequest } from "@/types/solver";
import { assertCpSatModelRepresentable, buildCompactCpSatModel, compactCpSatSuccessors } from "../cpsatModel";
import { SolveTimeLimitError } from "../solveBudget";
import { isMemoryFailure } from "@/services/solverResources";

const proto = protobuf.Root.fromJSON(descriptor as protobuf.INamespace).lookupType(
    "operations_research.sat.CpModelProto",
);
interface Decoded {
    variables: Array<{ domain: number[]; name?: string }>;
    constraints: Array<{
        routes?: { tails: number[]; heads: number[]; literals: number[] };
        circuit?: { tails: number[]; heads: number[]; literals: number[] };
        enforcementLiteral?: number[];
        linear?: { vars: number[]; coeffs: number[]; domain: number[] };
    }>;
    objective: { vars: number[]; coeffs: number[] };
}
function decode(bytes: Uint8Array): Decoded {
    const model = proto.toObject(proto.decode(bytes), { longs: Number }) as Decoded;
    expect(proto.verify(model)).toBeNull();
    return model;
}
function request(overrides: Partial<CvrpSolveRequest> = {}): CvrpSolveRequest {
    return {
        distanceMatrix: [
            [0, 10, 20, 30],
            [11, 0, 12, 13],
            [21, 22, 0, 23],
            [31, 32, 33, 0],
        ],
        depot: 0,
        demands: [0, 1, 2, 3],
        vehicleCapacity: 10,
        numVehicles: 3,
        timeLimitSeconds: 10,
        ...overrides,
    };
}
afterEach(() => vi.restoreAllMocks());

describe("compact CP-SAT model", () => {
    it("guards only the native signed-32-bit byte and variable representation limits", () => {
        expect(() => assertCpSatModelRepresentable(0x7fff_ffff, 0x7fff_ffff)).not.toThrow();
        for (const [bytes, variables] of [
            [0x8000_0000, 1],
            [1, 0x8000_0000],
        ]) {
            let failure: unknown;
            try {
                assertCpSatModelRepresentable(bytes!, variables!);
            } catch (cause) {
                failure = cause;
            }
            expect(failure).toBeInstanceOf(Error);
            expect((failure as Error).message).toMatch(/signed 32-bit lengths and variable indices/);
            expect(isMemoryFailure(failure)).toBe(true);
        }
    });

    it("preserves the existing rounding, zero clamp and missing-demand normalization", () => {
        const req = request({ demands: [999, 1.5, -1.5] });
        const compact = buildCompactCpSatModel(req, "cvrp");
        expect(compact.demands).toEqual([0, 2, 0, 0]);
        expect(decode(compact.bytes).variables.slice(compact.arcCount)).toEqual([
            { domain: [2, 10] },
            { domain: [0, 10] },
            { domain: [0, 10] },
        ]);
    });

    it.each([Number.NaN, Number.POSITIVE_INFINITY, Number.MAX_SAFE_INTEGER + 1])(
        "rejects an unsafe demand %s after normalization",
        (demand) => {
            expect(() => buildCompactCpSatModel(request({ demands: [0, demand, 2, 3] }), "cvrp")).toThrow(
                /safe integer demands after rounding/,
            );
        },
    );

    it("decodes into the original complete TSP circuit and integer objective", () => {
        const req: TspSolveRequest = { ...request(), depot: 2 };
        req.distanceMatrix[1]![2] = 2 ** 40 + 125;
        const compact = buildCompactCpSatModel(req, "tsp");
        const decoded = decode(compact.bytes);
        expect(decoded.variables).toEqual(Array.from({ length: 12 }, () => ({ domain: [0, 1] })));
        const tails: number[] = [],
            heads: number[] = [],
            coeffs: number[] = [];
        for (let i = 0; i < 4; i++)
            for (let j = 0; j < 4; j++)
                if (i !== j) {
                    tails.push(i);
                    heads.push(j);
                    coeffs.push(req.distanceMatrix[i]![j]!);
                }
        const literals = Array.from({ length: 12 }, (_, i) => i);
        expect(decoded.constraints).toEqual([{ circuit: { tails, heads, literals } }]);
        expect(decoded.objective).toEqual({ vars: literals, coeffs });
    });

    it("keeps fleet bounds, cumulative delivery and the nonzero depot mapping", () => {
        const req = request({ depot: 2, demands: [3, 1, 0, 2], minimumVehicles: 2, numVehicles: 2 });
        const compact = buildCompactCpSatModel(req, "cvrp");
        const decoded = decode(compact.bytes);
        expect(compact.wireToOriginal).toEqual([2, 0, 1, 3]);
        expect(decoded.variables.slice(12)).toEqual([{ domain: [3, 10] }, { domain: [1, 10] }, { domain: [2, 10] }]);
        expect(decoded.constraints[1]).toEqual({ linear: { vars: [0, 1, 2], coeffs: [1, 1, 1], domain: [2, 2] } });
        expect(decoded.constraints).toContainEqual({
            enforcementLiteral: [0],
            linear: { vars: [12], coeffs: [1], domain: [3, 3] },
        });
        expect(decoded.constraints).toContainEqual({
            enforcementLiteral: [4],
            linear: { vars: [13, 12], coeffs: [1, -1], domain: [1, 1] },
        });
        const values = Array<number>(15).fill(0);
        const routes = decoded.constraints[0]!.routes!;
        for (let arc = 0; arc < routes.tails.length; arc++) {
            const edge = `${routes.tails[arc]}:${routes.heads[arc]}`;
            if (["0:1", "1:2", "2:0", "0:3", "3:0"].includes(edge)) values[routes.literals[arc]!] = 1;
        }
        expect(compactCpSatSuccessors(compact, values)).toEqual({ successor: [3, 2, 0, 0], depotOut: [1, 3] });
    });

    it("excludes only capacity-impossible arcs while retaining depot and zero-demand arcs", () => {
        const compact = buildCompactCpSatModel(request({ demands: [0, 6, 5, 0], vehicleCapacity: 10 }), "cvrp");
        const routes = decode(compact.bytes).constraints[0]!.routes!;
        const edges = routes.tails.map((tail, i) => `${tail}:${routes.heads[i]}`);
        expect(compact.arcCount).toBe(10);
        expect(edges).not.toContain("1:2");
        expect(edges).not.toContain("2:1");
        expect(edges).toContain("1:3");
        expect(edges).toContain("3:1");
        expect(edges.filter((edge) => edge.startsWith("0:") || edge.endsWith(":0"))).toHaveLength(6);
    });

    it("preserves exactly the capacity and fleet feasible route partitions", () => {
        const req = request({
            distanceMatrix: Array.from({ length: 5 }, (_, i) => Array.from({ length: 5 }, (_, j) => Math.abs(i - j))),
            demands: [0, 2, 4, 3, 1],
            vehicleCapacity: 6,
            numVehicles: 3,
            minimumVehicles: 2,
        });
        const compact = buildCompactCpSatModel(req, "cvrp");
        const decoded = decode(compact.bytes);
        const circuit = decoded.constraints[0]!.routes!;
        const arcByEdge = new Map(
            circuit.tails.map((tail, i) => [`${tail}:${circuit.heads[i]}`, circuit.literals[i]!]),
        );
        const permutations = (nodes: number[]): number[][] =>
            nodes.length
                ? nodes.flatMap((node) => permutations(nodes.filter((n) => n !== node)).map((rest) => [node, ...rest]))
                : [[]];
        let feasible = 0;
        for (const order of permutations([1, 2, 3, 4]))
            for (let cuts = 0; cuts < 8; cuts++) {
                const routes: number[][] = [[]];
                order.forEach((node, index) => {
                    routes.at(-1)!.push(node);
                    if (index < 3 && cuts & (1 << index)) routes.push([]);
                });
                const expected =
                    routes.length >= 2 &&
                    routes.length <= 3 &&
                    routes.every((route) => route.reduce((sum, node) => sum + req.demands[node]!, 0) <= 6);
                const values = Array<number>(decoded.variables.length).fill(0);
                let allowed = true;
                for (const route of routes) {
                    let load = 0,
                        previous = 0;
                    for (const node of [...route, 0]) {
                        const arc = arcByEdge.get(`${previous}:${node}`);
                        if (arc === undefined) allowed = false;
                        else values[arc] = 1;
                        if (node) {
                            load += req.demands[node]!;
                            values[compact.arcCount + node - 1] = load;
                        }
                        previous = node;
                    }
                }
                allowed &&= decoded.variables.every(
                    (variable, index) => values[index]! >= variable.domain[0]! && values[index]! <= variable.domain[1]!,
                );
                allowed &&= decoded.constraints.every((constraint) => {
                    if (
                        !constraint.linear ||
                        (constraint.enforcementLiteral &&
                            !constraint.enforcementLiteral.every((literal) => values[literal] === 1))
                    )
                        return true;
                    const linear = constraint.linear;
                    const sum = linear.vars.reduce(
                        (result, variable, i) => result + values[variable]! * linear.coeffs[i]!,
                        0,
                    );
                    return sum >= linear.domain[0]! && sum <= linear.domain[1]!;
                });
                expect(allowed).toBe(expected);
                if (expected) feasible++;
            }
        expect(feasible).toBeGreaterThan(0);
    });

    it("stops preparation cooperatively inside a construction pass", () => {
        let calls = 0;
        vi.spyOn(performance, "now").mockImplementation(() => (calls++ < 2 ? 0 : 10));
        const req = request({
            distanceMatrix: Array.from({ length: 80 }, () => new Array<number>(80).fill(1)),
            demands: new Array<number>(80).fill(1),
        });
        expect(() => buildCompactCpSatModel(req, "cvrp", performance.timeOrigin + 5)).toThrow(SolveTimeLimitError);
        expect(calls).toBeLessThan(8);
    });

    it("rejects an already exhausted budget before reading the matrix", () => {
        const req = request();
        Object.defineProperty(req, "distanceMatrix", {
            get: () => {
                throw new Error("matrix should not be read");
            },
        });
        expect(() => buildCompactCpSatModel(req, "cvrp", 0)).toThrow(SolveTimeLimitError);
    });

    it("keeps actual buffer allocation failures as resource errors", () => {
        const original = globalThis.Uint8Array;
        vi.stubGlobal(
            "Uint8Array",
            class extends original {
                constructor() {
                    super(0);
                    throw new RangeError("allocation failed");
                }
            },
        );
        try {
            let failure: unknown;
            try {
                buildCompactCpSatModel(request(), "cvrp");
            } catch (cause) {
                failure = cause;
            }
            expect(failure).toBeInstanceOf(Error);
            expect((failure as Error).message).toMatch(/could not allocate its serialized model/);
            expect(isMemoryFailure(failure)).toBe(true);
        } finally {
            vi.unstubAllGlobals();
        }
    });

    it.each([127, 128, 16383, 16384, 2 ** 32 + 1, Number.MAX_SAFE_INTEGER])(
        "round trips int64 boundary %s without truncation",
        (cost) => {
            const req = request({ vehicleCapacity: cost });
            req.distanceMatrix[0]![1] = cost;
            const decoded = decode(buildCompactCpSatModel(req, "cvrp").bytes);
            expect(decoded.objective.coeffs[0]).toBe(cost);
            expect(decoded.variables.at(-1)!.domain[1]).toBe(cost);
        },
    );

    it.each([-1, 0.5, Number.NaN, Number.POSITIVE_INFINITY, Number.MAX_SAFE_INTEGER + 1])(
        "rejects invalid numeric cost %s without writing a malformed proto",
        (cost) => {
            const req = request();
            req.distanceMatrix[0]![1] = cost;
            expect(() => buildCompactCpSatModel(req, "cvrp")).toThrow(/nonnegative safe integer arc costs/);
        },
    );

    it.each([-1, 0, 0.5, Number.NaN, Number.POSITIVE_INFINITY, Number.MAX_SAFE_INTEGER + 1])(
        "rejects invalid capacity %s",
        (vehicleCapacity) => {
            expect(() => buildCompactCpSatModel(request({ vehicleCapacity }), "cvrp")).toThrow(/integer capacity/);
        },
    );

    it("serializes variable indices across both protobuf size boundaries", () => {
        const req = request({
            distanceMatrix: Array.from({ length: 130 }, (_, i) =>
                Array.from({ length: 130 }, (_, j) => Math.abs(i - j)),
            ),
            demands: Array<number>(130).fill(1),
        });
        const decoded = decode(buildCompactCpSatModel(req, "cvrp").bytes);
        expect(decoded.constraints[0]!.routes!.literals).toContain(16384);
        expect(decoded.objective.vars).toEqual(Array.from({ length: 130 * 129 }, (_, i) => i));
        expect(decoded.variables).toHaveLength(130 * 129 + 129);
    });
});
