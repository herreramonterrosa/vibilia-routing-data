import type { CvrpSolveRequest, TspSolveRequest } from "@/types/solver";
import { budgetNow, SolveTimeLimitError } from "./solveBudget";

/** The pinned cp_model.proto field numbers. Scalar repeated fields may use
 * unpacked wire encoding: protobuf accepts this even when packed is preferred.
 * Writing directly avoids protobufjs's per-value linked writer operations and
 * the much larger intermediate graph of variables/constraints/name strings. */
class WireWriter {
    length = 0;
    constructor(readonly bytes?: Uint8Array) {}

    uint(value: number): void {
        if (!this.bytes) {
            this.length += varintSize(value);
            return;
        }
        if (value < 0) {
            // The only negative model value is the load coefficient -1.
            if (value !== -1) throw new Error("Unexpected negative CP-SAT model value.");
            for (let i = 0; i < 9; i++) this.bytes[this.length++] = 255;
            this.bytes[this.length++] = 1;
            return;
        }
        while (value >= 128) {
            this.bytes[this.length++] = (value % 128) | 128;
            value = Math.floor(value / 128);
        }
        this.bytes[this.length++] = value;
    }

    scalar(field: number, value: number): void {
        this.uint(field * 8);
        this.uint(value);
    }

    message(field: number, length: number): void {
        this.uint(field * 8 + 2);
        this.uint(length);
    }
}

function varintSize(value: number): number {
    if (value < 0) return 10;
    let size = 1;
    while (value >= 128) {
        value = Math.floor(value / 128);
        size++;
    }
    return size;
}

/** SolveCpModelWithParameters takes a signed int byte length, and protobuf
 * variable references are int32. These are engine representation limits,
 * independent of the number of locations or available browser memory. */
export function assertCpSatModelRepresentable(bytes: number, variables: number): void {
    if (
        !Number.isSafeInteger(bytes) ||
        !Number.isSafeInteger(variables) ||
        bytes < 0 ||
        variables < 0 ||
        bytes > 0x7fff_ffff ||
        variables > 0x7fff_ffff
    ) {
        throw new Error(
            `CP-SAT cannot allocate a model with ${bytes} serialized bytes and ${variables} variables: its native API uses signed 32-bit lengths and variable indices.`,
        );
    }
}

export interface CompactCpSatModel {
    bytes: Uint8Array;
    wireToOriginal: number[];
    demands: number[] | undefined;
    capacity: number | undefined;
    arcCount: number;
    deadlineAtMs: number;
}

/** No arbitrary node cap. The clock and actual typed-buffer/native allocations
 * limit construction. Check during every pass, including excluded arcs, so a
 * model that cannot be prepared in budget never starts native search. */
export function cpSatCheckpoint(deadlineAtMs: number): () => void {
    let operations = 0;
    return () => {
        if (operations++ % 4096 === 0 && budgetNow() >= deadlineAtMs) throw new SolveTimeLimitError();
    };
}

function arcAllowed(i: number, j: number, demands: number[] | undefined, capacity: number | undefined): boolean {
    return i !== j && (i === 0 || j === 0 || !demands || demands[i]! + demands[j]! <= capacity!);
}

/** Removing an arc between two customers whose combined delivery exceeds Q is
 * an exact implication of capacity. There is no nearest-neighbour pruning. */
function arcs(
    n: number,
    demands: number[] | undefined,
    capacity: number | undefined,
    checkpoint: () => void,
    visit: (i: number, j: number, variable: number) => void,
): void {
    let variable = 0;
    for (let i = 0; i < n; i++) {
        for (let j = 0; j < n; j++) {
            checkpoint();
            if (arcAllowed(i, j, demands, capacity)) visit(i, j, variable++);
        }
    }
}

function writeLoad(
    w: WireWriter,
    arc: number,
    targetLoad: number,
    sourceLoad: number | undefined,
    demand: number,
): void {
    const linearSize =
        1 +
        varintSize(targetLoad) +
        2 +
        2 * (1 + varintSize(demand)) +
        (sourceLoad === undefined ? 0 : 1 + varintSize(sourceLoad) + 11);
    const constraintSize = 1 + varintSize(arc) + 1 + varintSize(linearSize) + linearSize;
    w.message(3, constraintSize);
    w.scalar(2, arc); // ConstraintProto.enforcement_literal
    w.message(12, linearSize);
    w.scalar(1, targetLoad);
    if (sourceLoad !== undefined) w.scalar(1, sourceLoad);
    w.scalar(2, 1);
    if (sourceLoad !== undefined) w.scalar(2, -1);
    w.scalar(3, demand);
    w.scalar(3, demand);
}

/** Same circuit/routes + objective + cumulative-load model as the object
 * builder, with optional debug names omitted. Its retained JS state is one
 * encoded buffer plus O(n) mapping/demands; there is no n² index grid. */
export function buildCompactCpSatModel(
    req: TspSolveRequest | CvrpSolveRequest,
    kind: "tsp" | "cvrp",
    deadlineAtMs = budgetNow() + req.timeLimitSeconds * 1000,
): CompactCpSatModel {
    const checkpoint = cpSatCheckpoint(deadlineAtMs);
    checkpoint();
    const n = req.distanceMatrix.length;
    if (
        !Number.isSafeInteger(req.depot) ||
        req.depot < 0 ||
        req.depot >= n ||
        req.distanceMatrix.some((row) => row.length !== n)
    ) {
        throw new Error("CP-SAT requires a square distance matrix and a valid depot.");
    }
    const wireToOriginal =
        kind === "cvrp"
            ? [req.depot, ...Array.from({ length: n }, (_, i) => i).filter((i) => i !== req.depot)]
            : Array.from({ length: n }, (_, i) => i);
    const cvrp = kind === "cvrp" ? (req as CvrpSolveRequest) : undefined;
    const capacity = cvrp?.vehicleCapacity;
    if (
        cvrp &&
        (!Number.isSafeInteger(capacity) ||
            capacity! < 1 ||
            !Number.isSafeInteger(cvrp.numVehicles) ||
            cvrp.numVehicles < 1 ||
            (cvrp.minimumVehicles !== undefined &&
                (!Number.isSafeInteger(cvrp.minimumVehicles) ||
                    cvrp.minimumVehicles < 1 ||
                    cvrp.minimumVehicles > cvrp.numVehicles)))
    ) {
        throw new Error("CP-SAT requires positive integer capacity and fleet bounds.");
    }
    const demands =
        cvrp &&
        wireToOriginal.map((original, wire) => (wire === 0 ? 0 : Math.max(0, Math.round(cvrp.demands[original] ?? 0))));
    if (demands?.some((demand) => !Number.isSafeInteger(demand))) {
        throw new Error("CP-SAT requires safe integer demands after rounding.");
    }
    let arcCount = 0;
    let circuitSize = 0;
    let objectiveSize = 0;
    arcs(n, demands, capacity, checkpoint, (i, j, variable) => {
        const cost = req.distanceMatrix[wireToOriginal[i]!]![wireToOriginal[j]!]!;
        if (!Number.isSafeInteger(cost) || cost < 0)
            throw new Error("CP-SAT requires nonnegative safe integer arc costs.");
        arcCount++;
        circuitSize += 3 + varintSize(i) + varintSize(j) + varintSize(variable);
        objectiveSize += 2 + varintSize(variable) + varintSize(cost);
    });
    assertCpSatModelRepresentable(0, arcCount + (cvrp ? n - 1 : 0));

    const write = (w: WireWriter): void => {
        for (let variable = 0; variable < arcCount; variable++) {
            checkpoint();
            w.message(2, 4); // IntegerVariableProto.domain = [0, 1]
            w.scalar(2, 0);
            w.scalar(2, 1);
        }
        if (cvrp) {
            for (let j = 1; j < n; j++) {
                checkpoint();
                w.message(2, 2 + varintSize(demands![j]!) + varintSize(capacity!));
                w.scalar(2, demands![j]!);
                w.scalar(2, capacity!);
            }
        }

        const circuitField = cvrp ? 23 : 15;
        w.message(3, varintSize(circuitField * 8 + 2) + varintSize(circuitSize) + circuitSize);
        w.message(circuitField, circuitSize);
        arcs(n, demands, capacity, checkpoint, (i, j, variable) => {
            w.scalar(cvrp ? 1 : 3, i);
            w.scalar(cvrp ? 2 : 4, j);
            w.scalar(cvrp ? 3 : 5, variable);
        });

        if (cvrp) {
            let fleetSize = 2 + varintSize(cvrp.minimumVehicles ?? 0) + varintSize(cvrp.numVehicles);
            for (let j = 1; j < n; j++) fleetSize += 3 + varintSize(j - 1);
            w.message(3, 1 + varintSize(fleetSize) + fleetSize);
            w.message(12, fleetSize);
            for (let j = 1; j < n; j++) {
                checkpoint();
                w.scalar(1, j - 1); // All depot-outgoing arcs precede customer arcs.
                w.scalar(2, 1);
            }
            w.scalar(3, cvrp.minimumVehicles ?? 0);
            w.scalar(3, cvrp.numVehicles);
            arcs(n, demands, capacity, checkpoint, (i, j, variable) => {
                if (j !== 0)
                    writeLoad(w, variable, arcCount + j - 1, i === 0 ? undefined : arcCount + i - 1, demands![j]!);
            });
        }
        w.message(4, objectiveSize);
        arcs(n, demands, capacity, checkpoint, (i, j, variable) => {
            w.scalar(1, variable);
            w.scalar(4, req.distanceMatrix[wireToOriginal[i]!]![wireToOriginal[j]!]!);
        });
    };

    const count = new WireWriter();
    write(count);
    assertCpSatModelRepresentable(count.length, arcCount + (cvrp ? n - 1 : 0));
    // Check immediately before and after the single allocation, not only at a
    // chunk boundary. A failed allocation remains a resource error.
    if (budgetNow() >= deadlineAtMs) throw new SolveTimeLimitError();
    let bytes: Uint8Array;
    try {
        bytes = new Uint8Array(count.length);
    } catch (cause) {
        throw new Error(`CP-SAT could not allocate its serialized model (${count.length} bytes).`, { cause });
    }
    if (budgetNow() >= deadlineAtMs) throw new SolveTimeLimitError();
    const writer = new WireWriter(bytes);
    write(writer);
    if (writer.length !== bytes.length)
        throw new Error("CP-SAT model serialization length differs from its allocation.");
    if (budgetNow() >= deadlineAtMs) throw new SolveTimeLimitError();
    return { bytes, wireToOriginal, demands, capacity, arcCount, deadlineAtMs };
}

/** Arc ordering is deterministic, so decoding needs no stored arc index grid. */
export function compactCpSatSuccessors(
    model: CompactCpSatModel,
    solution: number[],
): { successor: number[]; depotOut: number[] } {
    const successor = new Array<number>(model.wireToOriginal.length).fill(-1);
    const depotOut: number[] = [];
    const checkpoint = cpSatCheckpoint(model.deadlineAtMs);
    arcs(model.wireToOriginal.length, model.demands, model.capacity, checkpoint, (i, j, variable) => {
        if (solution[variable] !== 1) return;
        successor[i] = j;
        if (i === 0) depotOut.push(j);
    });
    return { successor, depotOut };
}
