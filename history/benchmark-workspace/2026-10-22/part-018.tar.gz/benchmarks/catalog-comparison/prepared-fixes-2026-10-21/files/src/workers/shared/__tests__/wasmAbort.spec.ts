import { afterEach, describe, expect, it, vi } from "vitest";
import { loadAbortAwareModule, runWithAbortReason, WasmAbortPending } from "../wasmAbort";
import { isMemoryFailure } from "@/services/solverResources";

afterEach(() => vi.restoreAllMocks());

describe("Emscripten abort reasons", () => {
    async function diagnosticModule() {
        vi.spyOn(console, "error").mockImplementation(() => {});
        let onAbort: (reason: unknown) => void = () => {};
        let printErr: (line: unknown) => void = () => {};
        const reported: Array<[string, string]> = [];
        const module = await loadAbortAwareModule(
            async (options) => {
                onAbort = options!.onAbort as typeof onAbort;
                printErr = options!.printErr as typeof printErr;
                return {};
            },
            "VROOM",
            (engine, reason) => reported.push([engine, reason]),
            { captureStderr: true },
        );
        return { module, onAbort, printErr, reported };
    }

    it("keeps libc++ stderr when C abort has an empty payload, including immediate notification", async () => {
        const { module, onAbort, printErr, reported } = await diagnosticModule();
        expect(() =>
            runWithAbortReason(module, "VROOM", () => {
                printErr("libc++abi: terminating due to uncaught exception of type std::bad_alloc");
                onAbort("");
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("VROOM aborted: libc++abi: terminating due to uncaught exception of type std::bad_alloc");
        expect(reported).toEqual([
            ["VROOM", "libc++abi: terminating due to uncaught exception of type std::bad_alloc"],
        ]);
        expect(isMemoryFailure(reported[0]![1])).toBe(true);
    });

    it("does not infer a memory failure from an empty abort or reuse prior solve diagnostics", async () => {
        const { module, onAbort, printErr, reported } = await diagnosticModule();
        runWithAbortReason(module, "VROOM", () => printErr("old std::bad_alloc diagnostic"));
        expect(() =>
            runWithAbortReason(module, "VROOM", () => {
                onAbort("");
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("VROOM aborted: Native abort without diagnostics.");
        expect(isMemoryFailure(reported[0]![1])).toBe(false);
    });

    it("retains stderr across pthread unwind until the delayed empty abort arrives", async () => {
        const { module, onAbort, printErr, reported } = await diagnosticModule();
        expect(() =>
            runWithAbortReason(module, "VROOM", () => {
                printErr("libc++abi: terminating due to std::bad_alloc");
                throw "unwind";
            }),
        ).toThrow(WasmAbortPending);
        expect(reported).toEqual([]);
        onAbort("");
        expect(reported).toEqual([["VROOM", "libc++abi: terminating due to std::bad_alloc"]]);
    });

    it("preserves concrete native reasons over unrelated stderr", async () => {
        const { module, onAbort, printErr } = await diagnosticModule();
        expect(() =>
            runWithAbortReason(module, "VROOM", () => {
                printErr("warning before a concrete assertion");
                onAbort("Assertion failed: valid route");
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("VROOM aborted: Assertion failed: valid route");
    });

    it("bounds captured stderr and keeps non-memory native errors as technical failures", async () => {
        const { module, onAbort, printErr, reported } = await diagnosticModule();
        expect(() =>
            runWithAbortReason(module, "VROOM", () => {
                printErr("old discarded std::bad_alloc diagnostic");
                for (let index = 0; index < 20; index++) printErr("x".repeat(1000));
                printErr("libc++abi: terminating due to std::system_error: thread constructor failed");
                onAbort("");
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("thread constructor failed");
        expect(reported[0]![1].length).toBeLessThanOrEqual(16 * 513);
        expect(isMemoryFailure(reported[0]![1])).toBe(false);
    });

    it("does not override another engine's stderr handler unless capture is requested", async () => {
        await loadAbortAwareModule(async (options) => {
            expect(options).not.toHaveProperty("printErr");
            return {};
        }, "CLI engine");
    });

    it("keeps a concrete abort reason through an unreachable trap", async () => {
        let onAbort: (reason: unknown) => void = () => {};
        const mod = await loadAbortAwareModule(async (options) => {
            onAbort = options!["onAbort"] as typeof onAbort;
            return {};
        }, "VROOM");
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                onAbort("OOM");
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("VROOM aborted: OOM");
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                throw new WebAssembly.RuntimeError("unreachable");
            }),
        ).toThrow("unreachable");
    });

    it("keeps an abort reason when module startup fails", async () => {
        await expect(
            loadAbortAwareModule(async (options) => {
                (options!["onAbort"] as (reason: unknown) => void)("Cannot enlarge memory arrays (OOM)");
                throw new WebAssembly.RuntimeError("unreachable");
            }, "OR-Tools"),
        ).rejects.toThrow("OR-Tools aborted during initialization: Cannot enlarge memory arrays (OOM)");
    });

    it("waits for a child-thread abort instead of reporting Emscripten's unwind sentinel", async () => {
        let onAbort: (reason: unknown) => void = () => {};
        const reported: Array<[string, string]> = [];
        const mod = await loadAbortAwareModule(
            async (options) => {
                onAbort = options!["onAbort"] as typeof onAbort;
                return {};
            },
            "VROOM",
            (engine, reason) => reported.push([engine, reason]),
        );
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                throw "unwind";
            }),
        ).toThrow(WasmAbortPending);
        expect(reported).toEqual([]);
        onAbort("OOM");
        expect(reported).toEqual([["VROOM", "OOM"]]);
        expect(() =>
            runWithAbortReason(mod, "VROOM", () => {
                throw new Error("unreachable");
            }),
        ).toThrow("unreachable");
    });
});
