/// <reference lib="webworker" />
import { jsonMatrix } from "../shared/jsonMatrix";
import type { DenseMatrix } from "@/lib/denseMatrix";
/**
 * Web Worker that solves CVRPTW through the VROOM wasm module.
 *
 * The same `solve(input_json, exploration_level)` embind entry used for CVRP also
 * handles time windows — VROOM models VRPTW natively, so no recompile was needed.
 * Two custom matrices are supplied: `durations` (travel minutes) drives the time
 * dimension and `costs` (distance metres) drives the objective. Jobs carry their
 * `time_windows` and `service`; the vehicle `time_window` is the shift horizon.
 * See compilations/vroom/instructions.md.
 */
import { reportFatalWasmAbort, runSolverWorker, type SolverRunContext } from "../shared/harness";
import { returningSearchSeconds } from "../shared/solveBudget";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import { vroomTimeoutMs } from "@/planner/engines/vroomAdapter";
import type { CvrptwRoute, CvrptwSolution, CvrptwSolveRequest } from "@/types/solver";

// Exploration threads per solve — half the pthread pool baked into vroom.js.
const VROOM_THREADS = 4;

interface VroomModule {
    solveWithTimeout: (inputJson: string, explorationLevel: number, nbThreads: number, timeoutMs: number) => string;
    version: () => string;
}

type VroomFactory = (opts?: Record<string, unknown>) => Promise<VroomModule>;

let modulePromise: Promise<VroomModule & AbortAwareModule> | null = null;

async function loadModule(): Promise<VroomModule & AbortAwareModule> {
    if (modulePromise) return modulePromise;
    modulePromise = (async () => {
        const url = new URL("/wasm/vroom.js", self.location.origin).toString();
        const mod = (await import(/* @vite-ignore */ url)) as { default: VroomFactory };
        return loadAbortAwareModule(mod.default, "VROOM", reportFatalWasmAbort, { captureStderr: true });
    })();
    return modulePromise;
}

interface VroomStep {
    type: "start" | "job" | "end" | string;
    location_index?: number;
}

interface VroomVehicleRoute {
    vehicle: number;
    steps: VroomStep[];
}

interface VroomOutput {
    code?: number;
    error?: string;
    routes?: VroomVehicleRoute[];
    unassigned?: Array<{ id: number; location_index?: number }>;
}

function buildInput(payload: CvrptwSolveRequest): string {
    const { distanceMatrix, timeMatrix, depot, demands, numVehicles, vehicleCapacity, timeWindows, serviceTimes } =
        payload;
    const durations = jsonMatrix(timeMatrix, (t) => Math.max(0, Math.round(t)));
    const costs = jsonMatrix(distanceMatrix, (d) => Math.max(0, Math.round(d)));
    const depotWindow = timeWindows[depot] ?? [0, payload.maxRouteMinutes];
    const shift: [number, number] = [depotWindow[0], Math.min(depotWindow[1], payload.maxRouteMinutes)];
    if (shift[1] < shift[0]) throw new Error("VROOM: latest return is before the shift begins.");
    // A cap at least as large as the latest possible window opening offset
    // cannot bind any stop; a tighter per-stop cap has no VROOM equivalent.
    const latestOpening = timeWindows.reduce((latest, [open]) => Math.max(latest, open), shift[0]);
    if (payload.waitMinutes < latestOpening - shift[0]) {
        throw new Error("VROOM cannot enforce a per-stop waiting cap. Choose OR-Tools.");
    }
    const vehicles = Array.from({ length: numVehicles }, (_, i) => ({
        id: i,
        start_index: depot,
        end_index: depot,
        // VROOM uses arrays so multi-dimensional capacities are supported; we
        // only model a single dimension. The time_window is the shift horizon.
        capacity: [vehicleCapacity],
        time_window: [shift[0], shift[1]],
    }));
    const jobs = [];
    for (let i = 0; i < durations.length; i++) {
        if (i === depot) continue;
        const tw = timeWindows[i] ?? [shift[0], shift[1]];
        jobs.push({
            id: i,
            location_index: i,
            delivery: [Math.max(0, Math.round(demands[i] ?? 0))],
            service: Math.max(0, Math.round(serviceTimes[i] ?? 0)),
            time_windows: [[tw[0], tw[1]]],
        });
    }
    return JSON.stringify({
        vehicles,
        jobs,
        // `durations` (minutes) feeds the time dimension; `costs` (metres) is the
        // objective, so VROOM minimises distance while honouring the windows.
        matrices: { car: { durations, costs } },
    });
}

function sequenceFromRoute(route: VroomVehicleRoute): number[] {
    const seq: number[] = [];
    for (const step of route.steps) {
        if (step.location_index != null) seq.push(step.location_index);
    }
    return seq;
}

function routeDistance(seq: number[], matrix: DenseMatrix): number {
    let cost = 0;
    for (let i = 0; i + 1 < seq.length; i++) cost += matrix[seq[i]!]![seq[i + 1]!]!;
    return cost;
}

function routeLoad(seq: number[], demands: number[]): number {
    let load = 0;
    for (const idx of seq) load += demands[idx] ?? 0;
    return load;
}

/**
 * Reconstructs the earliest-feasible service-start minute at each stop from the
 * route sequence — identical logic to the OR-Tools and PyVRP workers, so the
 * schedule the UI shows is the same regardless of which engine produced it.
 */
function scheduleOfRoute(nodes: number[], payload: CvrptwSolveRequest): { arrivalTimes: number[]; endTime: number } {
    const { timeMatrix, serviceTimes, timeWindows, depot } = payload;
    const arrivalTimes: number[] = [];
    let clock = timeWindows[depot]?.[0] ?? 0;
    for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i]!;
        if (i > 0) {
            const prev = nodes[i - 1]!;
            clock += timeMatrix[prev]?.[node] ?? 0;
        }
        const open = timeWindows[node]?.[0] ?? 0;
        const serviceStart = Math.max(clock, open);
        arrivalTimes.push(serviceStart);
        // The depot at the end has no service time; mid-route stops do.
        const isLastDepot = i === nodes.length - 1 && node === depot;
        clock = serviceStart + (isLastDepot ? 0 : (serviceTimes[node] ?? 0));
    }
    return { arrivalTimes, endTime: clock };
}

async function solve(payload: CvrptwSolveRequest, context: SolverRunContext<CvrptwSolution>): Promise<CvrptwSolution> {
    const mod = await loadModule();
    const requestStart = performance.now();
    // Exploration level mirrors the CLI `-x` flag (0 fast .. 5 default/best).
    const level = payload.vroomExplorationLevel ?? 5;
    const outJson = runWithAbortReason(mod, "VROOM", () =>
        mod.solveWithTimeout(
            buildInput(payload),
            level,
            VROOM_THREADS,
            vroomTimeoutMs(returningSearchSeconds(context.deadlineAtMs, payload.timeLimitSeconds)),
        ),
    );
    const clientMs = Math.round(performance.now() - requestStart);
    const result = JSON.parse(outJson) as VroomOutput;

    if (result.code != null && result.code !== 0) {
        return empty("ERROR", clientMs, result.error ?? `VROOM error code ${result.code}`);
    }
    const routes: CvrptwRoute[] = (result.routes ?? [])
        .map((r) => ({ vehicle: r.vehicle, sequence: sequenceFromRoute(r) }))
        .filter((r) => r.sequence.length > 2)
        .map((r) => {
            const { arrivalTimes, endTime } = scheduleOfRoute(r.sequence, payload);
            return {
                vehicle: r.vehicle,
                sequence: r.sequence,
                distance: routeDistance(r.sequence, payload.distanceMatrix),
                load: routeLoad(r.sequence, payload.demands),
                endTime,
                arrivalTimes,
            };
        });
    const totalCost = routes.reduce((s, r) => s + r.distance, 0);
    // Job IDs are matrix indices in this adapter, even if a native result omits location_index.
    const unassignedBySolver = result.unassigned?.map((job) => job.location_index ?? job.id);
    const dropped = unassignedBySolver ?? [];

    return {
        status: "FEASIBLE",
        totalCost,
        wallTimeMs: clientMs,
        clientMs,
        routes,
        dropped,
        ...(unassignedBySolver === undefined ? {} : { unassignedBySolver }),
    };
}

function empty(status: CvrptwSolution["status"], clientMs: number, error?: string): CvrptwSolution {
    return { status, error, totalCost: 0, wallTimeMs: clientMs, clientMs, routes: [], dropped: [] };
}

runSolverWorker({ init: loadModule, solve });
