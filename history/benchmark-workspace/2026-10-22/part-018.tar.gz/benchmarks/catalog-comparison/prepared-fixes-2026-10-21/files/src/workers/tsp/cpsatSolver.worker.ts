/// <reference lib="webworker" />
/**
 * Web Worker that loads the CP-SAT WASM module and solves TSP via a `circuit`
 * constraint.
 *
 * Model:
 *   - N nodes → N*(N-1) BoolVars `x_ij`, one literal per directed arc i→j (i≠j).
 *   - One `CircuitConstraint(tails=[i...], heads=[j...], literals=[var_ij...])`.
 *   - Objective: minimize Σ dist_ij · x_ij.
 *
 * The host communicates with this worker through the typed message protocol
 * defined in `shared/tsp-messages.ts`. The malloc/HEAPU8/free pattern below is
 * documented in `compilations/cpsat/instructions.md`.
 */
// `protobufjs/light` excludes the .proto text parser (and its fs lookup) which
// Vite externalizes and warns about in browser builds. We pre-compile the .proto
// files to a JSON descriptor at build time (see compilations/cpsat/build.sh) and
// hydrate it here with Root.fromJSON.
import protobuf from "protobufjs/light";
import protoDescriptor from "@compilations/cpsat/output/protos.json";
import { reportFatalWasmAbort, runSolverWorker, type SolverRunContext } from "../shared/harness";
import { budgetNow, returningSearchSeconds, SolveTimeLimitError } from "../shared/solveBudget";
import { buildCompactCpSatModel, compactCpSatSuccessors, type CompactCpSatModel } from "../shared/cpsatModel";
import { callCpSat, type CpSatModule } from "../shared/cpsatAbi";
import { loadAbortAwareModule, runWithAbortReason, type AbortAwareModule } from "../shared/wasmAbort";
import type { SolveStatus, TspSolution, TspSolveRequest } from "@/types/solver";

interface ProtoTypes {
    CpSolverResponse: protobuf.Type;
    SatParameters: protobuf.Type;
}

interface InitState {
    mod: CpSatModule & AbortAwareModule;
    types: ProtoTypes;
}

let initPromise: Promise<InitState> | null = null;

async function init(): Promise<InitState> {
    if (initPromise) return initPromise;
    initPromise = (async () => {
        const root = protobuf.Root.fromJSON(protoDescriptor as protobuf.INamespace);
        const types: ProtoTypes = {
            CpSolverResponse: root.lookupType("operations_research.sat.CpSolverResponse"),
            SatParameters: root.lookupType("operations_research.sat.SatParameters"),
        };

        const wasmUrl = `${self.location.origin}/wasm/cp_sat.js`;
        const loader = (await import(/* @vite-ignore */ wasmUrl)) as {
            default: (opts?: Record<string, unknown>) => Promise<CpSatModule>;
        };
        const mod = await loadAbortAwareModule(loader.default, "CP-SAT", reportFatalWasmAbort);
        return { mod, types };
    })();
    return initPromise;
}

const STATUS_MAP: Record<number, SolveStatus> = {
    0: "NO_SOLUTION", // UNKNOWN
    1: "ERROR", // MODEL_INVALID
    2: "FEASIBLE", // FEASIBLE
    3: "NO_SOLUTION", // INFEASIBLE
    4: "OPTIMAL", // OPTIMAL
};

interface DecodedResponse {
    status: number;
    solution?: number[];
    objectiveValue?: number;
    wallTime?: number;
}

/** Rebuilds the visit sequence by following arcs with value 1, starting from the depot. */
function reconstructSequence(req: TspSolveRequest, model: CompactCpSatModel, solution: number[]): number[] {
    const n = req.distanceMatrix.length;
    const { successor } = compactCpSatSuccessors(model, solution);

    const seq: number[] = [req.depot];
    let cur = req.depot;
    for (let step = 0; step < n; step++) {
        const next = successor[cur];
        if (next == null || next < 0) break;
        seq.push(next);
        if (next === req.depot) break;
        cur = next;
    }
    return seq;
}

async function solveWithinBudget(
    payload: TspSolveRequest,
    context: SolverRunContext<TspSolution>,
): Promise<TspSolution> {
    const requestStart = performance.now();
    const { mod, types } = await init();

    const model = buildCompactCpSatModel(payload, "tsp", context.deadlineAtMs);
    const reqBytes = model.bytes;

    const paramsMsg = types.SatParameters.create({
        maxTimeInSeconds: returningSearchSeconds(model.deadlineAtMs, payload.timeLimitSeconds),
        // The committed CP-SAT module shares the non-threaded OR-Tools archive
        // with Routing. One search worker avoids spawning unavailable pthreads.
        numWorkers: 1,
    });
    const paramBytes = types.SatParameters.encode(paramsMsg).finish();

    const resBytes = runWithAbortReason(mod, "CP-SAT", () => callCpSat(mod, reqBytes, paramBytes));

    if (budgetNow() >= model.deadlineAtMs) throw new SolveTimeLimitError();
    const decoded = types.CpSolverResponse.decode(resBytes);
    const obj = types.CpSolverResponse.toObject(decoded, {
        longs: Number,
        enums: Number,
        defaults: true,
    }) as DecodedResponse;

    const status = STATUS_MAP[obj.status] ?? "ERROR";
    const wallTimeMs = Math.round((obj.wallTime ?? 0) * 1000);
    const clientMs = Math.round(performance.now() - requestStart);

    if (status === "ERROR" || status === "NO_SOLUTION" || !obj.solution) {
        return { status, totalCost: 0, wallTimeMs, clientMs, sequence: [] };
    }

    return {
        status,
        totalCost: Math.round(obj.objectiveValue ?? 0),
        wallTimeMs,
        clientMs,
        sequence: reconstructSequence(payload, model, obj.solution),
    };
}

async function solve(payload: TspSolveRequest, context: SolverRunContext<TspSolution>): Promise<TspSolution> {
    const start = performance.now();
    try {
        return await solveWithinBudget(payload, context);
    } catch (cause) {
        if (!(cause instanceof SolveTimeLimitError)) throw cause;
        return {
            status: "NO_SOLUTION",
            totalCost: 0,
            wallTimeMs: 0,
            clientMs: Math.round(performance.now() - start),
            sequence: [],
            error: cause.message,
        };
    }
}

runSolverWorker({ init: init, solve });
